#ifndef _welcome_
#define _welcome_

#include <iostream>
#include <conio.h>
#include "antHeaderPlusPlus.h"
#include <windows.h>
#include"home.h"

using namespace std;

void Welcome(){
    system("cls");
gotoxy(20,0);foreColor(3);cout<<" ___            _                  	  ____";
Sleep(200);
gotoxy(20,1);foreColor(3);cout<<"| __|_ __  _ __| |___ _  _ ___ ___   |  \\/  |__ _ _ _  __ _ __ _ ___ _ __  ___ _ _| |_ ";
Sleep(200); 
gotoxy(20,2);foreColor(3);cout<<"| _|| '  \\| '_ \\ / _ \\ || / -_) -_)  | |\\/| / _` | ' \\/ _` / _` / -_) '  \\/ -_) ' \\  _|";
Sleep(200); 
gotoxy(20,3);foreColor(3);cout<<"|___|_|_|_| .__/_\\___/\\_, \\___\\___|  |_|  |_\\__,_|_||_\\__,_\\__, \\___|_|_|_\\___|_||_\\__|";
Sleep(200); 
gotoxy(20,4);foreColor(3);cout<<"          |_|         |__/                                 |___/                       ";
                         
Sleep(300);               
Sleep(300);
gotoxy(5,5);foreColor(1);cout<<" .----------------. ";
gotoxy(105,5);foreColor(1);cout<<" .----------------. ";
gotoxy(35, 7); cout << "                                               /\\      /\\";
Sleep(200);
gotoxy(5,6);foreColor(2);cout<<"| .--------------. |";
gotoxy(105,6);foreColor(2);cout<<"| .--------------. |";
gotoxy(35, 8);foreColor(2); cout << "                                               ||______||";
Sleep(200);
gotoxy(5,7);foreColor(3);cout<<"| |      __      | |";
gotoxy(105,7);foreColor(3);cout<<"| |      __      | |";
gotoxy(35, 9);foreColor(2); cout << "                                               || ^  ^ ||";
Sleep(200);
gotoxy(5,8);foreColor(4);cout<<"| |     /  \\     | |";
gotoxy(105,8);foreColor(4);cout<<"| |     /  \\     | |";
 gotoxy(35, 10);foreColor(2); cout << "                                               \\| |  | |/";
Sleep(200);
gotoxy(5,9);foreColor(5);cout<<"| |    / /\\ \\    | |";
gotoxy(105,9);foreColor(5);cout<<"| |    / /\\ \\    | |";
gotoxy(35, 11);foreColor(2); cout << "                                                |______|";
Sleep(200);
gotoxy(5,10);foreColor(6);cout<<"| |   / ____ \\   | |";
gotoxy(105,10);foreColor(6);cout<<"| |   / ____ \\   | |";
gotoxy(35, 12);foreColor(2); cout << "              __                                |  __  |";
Sleep(200);
gotoxy(5,11);foreColor(7);cout<<"| | _/ /    \\ \\_ | |";
gotoxy(105,11);foreColor(7);cout<<"| | _/ /    \\ \\_ | |";
gotoxy(35, 13);foreColor(2); cout << "             /  \\       ________________________|_/  \\_|__";
Sleep(200);
gotoxy(5,12);foreColor(8);cout<<"| ||____|  |____|| |";
gotoxy(105,12);foreColor(8);cout<<"| ||____|  |____|| |";
gotoxy(35, 14);foreColor(2); cout << "            / ^^ \\     /=========================/ ^^ \\===|";
Sleep(200);
gotoxy(5,13);foreColor(9);cout<<"| |              | |";
gotoxy(105,13);foreColor(9);cout<<"| |              | |";
gotoxy(35, 15);foreColor(2); cout << "           /  []  \\   /=========================/  []  \\==|";
Sleep(200);
gotoxy(5,14);foreColor(1);cout<<"| '--------------' |";
gotoxy(105,14);foreColor(1);cout<<"| '--------------' |";
gotoxy(35, 16);foreColor(2); cout << "          /________\\ /=========================/________\\=|";
Sleep(200);
gotoxy(5,15);foreColor(2);cout<<" '----------------' ";
gotoxy(105,15);foreColor(2);cout<<" '----------------' ";
gotoxy(35, 17);foreColor(2); cout << "       *  |        |/==========================|        |=|";

gotoxy(5, 16); foreColor(1); cout << " .-----------------." ;
gotoxy(105, 17); foreColor(2); cout << "| .--------------. |";
gotoxy(35, 18);foreColor(2); cout << "      *** | ^^  ^^ |---------------------------| ^^  ^^ |--";
Sleep(200);
gotoxy(5, 17); foreColor(2); cout << "| .--------------. |";
gotoxy(105, 18); foreColor(3); cout << "| | ____  _____  | |";
gotoxy(35, 19);foreColor(2); cout << "     *****| []  [] |           _____           | []  [] | |";
Sleep(200);
gotoxy(5, 18); foreColor(3); cout << "| | ____  _____  | |";
gotoxy(105, 19); foreColor(4); cout << "| ||_   \\|_   _| | |";
gotoxy(35, 20);foreColor(2); cout << "    *******        |          /_____\\          |      * | |";
Sleep(200);
gotoxy(5, 19); foreColor(4); cout << "| ||_   \\|_   _| | |";
gotoxy(105, 20); foreColor(5); cout << "| |  |   \\ | |   | |";
gotoxy(35, 21);foreColor(2); cout << "   *********^^  ^^ |  ^^  ^^  |  |  |  ^^  ^^  |     ***| |";
Sleep(200);
gotoxy(5, 20); foreColor(5); cout << "| |  |   \\ | |   | |";
gotoxy(105, 21); foreColor(6); cout << "| |  | |\\ \\| |   | |";
gotoxy(35, 22);foreColor(2); cout << "  ***********]  [] |  []  []  |  |  |  []  []  | ===***** |";
Sleep(200);
gotoxy(5, 21); foreColor(6); cout << "| |  | |\\ \\| |   | |";
gotoxy(105, 22); foreColor(7); cout << "| | _| |_\\   |_  | |";
gotoxy(35, 23);foreColor(2); cout << " *************     |         @|__|__|@         |/ |*******|";
Sleep(200);
gotoxy(5, 22); foreColor(7); cout << "| | _| |_\\   |_  | |";
gotoxy(105, 23); foreColor(8); cout << "| ||_____|\\____| | |";
gotoxy(35, 24);foreColor(2); cout << "***************   ***********--=====--**********| *********";
Sleep(200);
gotoxy(5, 23); foreColor(8); cout << "| ||_____|\\____| | |";
gotoxy(105, 24); foreColor(9); cout << "| |              | |";
gotoxy(35, 25);foreColor(2); cout << "***************___*********** |=====| **********|***********";
Sleep(200);
gotoxy(5, 24); foreColor(9); cout << "| |              | |";
gotoxy(35, 26);foreColor(2); cout << " *************     ********* /=======\\ ******** | *********";
Sleep(200);
gotoxy(5, 25); foreColor(1); cout << "| '--------------' |";
gotoxy(105, 25); foreColor(1); cout << "| '--------------' |";
Sleep(200);
gotoxy(5, 26); foreColor(2); cout << " '----------------' ";
gotoxy(105, 26); foreColor(2); cout << " '----------------' ";
Sleep(300);


gotoxy(5, 27); foreColor(1); cout << " .----------------. ";
gotoxy(105, 27); foreColor(1); cout << " .----------------. ";
Sleep(200);
gotoxy(5, 28); foreColor(2); cout << "| .--------------. |";
gotoxy(105, 28); foreColor(2); cout << "| .--------------. |";
Sleep(200);
gotoxy(5, 29); foreColor(3); cout << "| |  _________   | |";
gotoxy(105, 29); foreColor(3); cout << "| |  _________   | |";
Sleep(200);
gotoxy(5, 30); foreColor(4); cout << "| | |  _   _  |  | |";
gotoxy(105, 30); foreColor(4); cout << "| | |  _   _  |  | |";
Sleep(200);
gotoxy(5, 31); foreColor(5); cout << "| | |_/ | | \\_|  | |";
gotoxy(105, 31); foreColor(5); cout << "| | |_/ | | \\_|  | |";
Sleep(200);
gotoxy(5, 32); foreColor(6); cout << "| |     | |      | |";
gotoxy(105, 32); foreColor(6); cout << "| |     | |      | |";
Sleep(200);
gotoxy(5, 33); foreColor(7); cout << "| |    _| |_     | |";
gotoxy(105, 33); foreColor(7); cout << "| |    _| |_     | |";
Sleep(200);
gotoxy(5, 34); foreColor(8); cout << "| |   |_____|    | |";
gotoxy(105, 34); foreColor(8); cout << "| |   |_____|    | |";
Sleep(200);
gotoxy(5, 35); foreColor(9); cout << "| |              | |";
gotoxy(105, 35); foreColor(9); cout << "| |              | |";
Sleep(200);
gotoxy(5, 36); foreColor(1); cout << "| '--------------' |";
gotoxy(105, 36); foreColor(1); cout << "| '--------------' |";
Sleep(200);
gotoxy(5, 37); foreColor(2); cout << " '----------------' ";
gotoxy(105, 37); foreColor(2); cout << " '----------------' ";
Sleep(200);
Sleep(300);

	gotoxy(40,40);foreColor(7);cout<<"Loding";
	char x=219;
	for(int i=0;i<=27;i++)
	{
		Sleep(100);
		cout<<x;
		
	}
	system("cls");

Sleep(300);
//	gotoxy(45,35);foreColor(5);cout<<"Welcome to Civil Servants Managment system";
//	gotoxy(50,36);foreColor(4);system("pause");
	Home();
}
#endif