#ifndef _register_
#define _register_

#include <iostream>
#include <conio.h>
#include "antHeaderPlusPlus.h"
#include "antheaderInput.h"
#include<fstream>
//#include"wellcom.h"
#include <direct.h>   // For _mkdir on Windows
#include <sys/stat.h> // For mkdir on Linux/Unix-based systems
#include <errno.h>     // For error handling
#include "menu_for_admin.h"

using namespace std;
class temp {
		string userName,Email,password;
		string searchName,searchPass,searchEmail;
		fstream file;
	public:
		void login();
		void signUP();
		void forgot();
};

temp objx;

// Right panel for additional information or options
//    DrawRectangle(38, 5, 78, 18, 2);
	const string folderPath = "AdminData"; // Folder for admin data
	const string filePath = folderPath + "/loginData.txt"; // Full path to the file
void temp::signUP() {


	// Create folder if it doesn't exist (Windows or Unix-based systems)
#if defined(_WIN32) || defined(_WIN64)
	if (_mkdir(folderPath.c_str()) == -1 && errno != EEXIST) {
		gotoxy(55, 21);
		foreColor(4);
		cout << "Error: Unable to create folder!";
		getch();
		return;
	}
#else
	if (mkdir(folderPath.c_str(), 0777) == -1 && errno != EEXIST) {
		gotoxy(55, 21);
		foreColor(4);
		cout << "Error: Unable to create folder!";
		getch();
		return;
	}
#endif

	// Check if file exists and contains data
	file.open(filePath, ios::in);
	if (file.is_open() && file.peek() != ifstream::traits_type::eof()) {
		gotoxy(55, 22);
		foreColor(4);
		cout << "Admin account already exists!";
		gotoxy(55, 23);
		foreColor(4);
		cout << "===> Press any key to Exit <===";
		file.close();
		getch();
		return;
	}
	file.close();

	// Display Input Fields
	DrawRectangle(42, 9, 70, 1, 2);
	gotoxy(45, 10);
	foreColor(7);
	cout << "Enter Your User Name :: ";
	DrawRectangle(42, 12, 70, 1, 2);
	gotoxy(45, 13);
	foreColor(7);
	cout << "Enter Your Email Address :: ";
	DrawRectangle(42, 15, 70, 1, 2);
	gotoxy(45, 16);
	foreColor(7);
	cout << "Enter Your Password :: ";

	
	while (true) {
		gotoxy(70, 10);foreColor(7);inputLetter(userName);fflush(stdin);cin.clear();
		if(userName!="\0"){
			gotoxy(55, 18);cout << string(30, ' ');
			break;
		}
		gotoxy(55, 18);foreColor(4);cout << "User Name cannot be empty! Please try again.";
		
	}

	// Input Email with Validation
	while (true) {
		gotoxy(75, 13);
		foreColor(7);
		getline(cin, Email);
		fflush(stdin);
		cin.clear();
		if (!Email.empty() && Email.find('@') != string::npos && Email.find('.') != string::npos) {
			gotoxy(55, 19);cout << string(30, ' ');
			break;
		}
	
		gotoxy(55, 19);
		foreColor(4);
		cout << "Invalid Email Address! Please try again.";
		gotoxy(75, 13);
		 // Clear input line visually
	}

	// Input Password with Hidden Characters
	while (true) {
		gotoxy(70, 16);
		foreColor(7);
		hidePassword(password);
		fflush(stdin);
		cin.clear();
		if (!password.empty()) {
			break;
		}
		// Clear password input
		password.clear(); // Reset input field
		gotoxy(55, 20);
		foreColor(4);
		cout << "Password cannot be empty! Please try again.";
		gotoxy(70, 16);
		cout << string(50, ' '); // Clear input line visually
	}

	// Save New Admin Data
	file.open(filePath, ios::out);
	if (!file.is_open()) {
		gotoxy(55, 21);
		foreColor(4);
		cout << "Error: Unable to create admin data file!";
		getch();
		return;
	}

	file << userName << "*" << Email << "*" << password << endl;
	file.close();

	gotoxy(55, 22);
	foreColor(2);
	cout << "Sign-Up Successful! Admin account created.";
	getch();
	menu_admin();
}

void temp::login() {
	// Drawing the input prompts
	DrawRectangle(42, 9, 70, 1, 2);
	gotoxy(45, 10);
	foreColor(7);
	cout << "Enter Your User Name :: ";
	DrawRectangle(42, 12, 70, 1, 2);
	gotoxy(45, 13);
	foreColor(7);
	cout << "Enter Your Password :: ";

	// Input User Name with Validation
	while (true) {
		gotoxy(70, 10);
		foreColor(7);
		inputLetter(searchName);
		fflush(stdin);
		cin.clear();
		if (!searchName.empty()) {
			gotoxy(55, 18);cout << string(30, ' ');
			break;
		}
		
		gotoxy(55, 18);foreColor(4);cout << "User Name cannot be empty!";
		
	}

	// Input Password with Validation
	while (true) {
		gotoxy(70, 13);
		foreColor(7);
		hidePassword(searchPass);
		fflush(stdin);
		cin.clear();
		if (!searchPass.empty()) {
			gotoxy(55, 19);cout << string(30, ' ');
			break;
		}
		
		gotoxy(55, 19);
		foreColor(4);
		cout << "Password cannot be empty!";
		
	}

	// Open loginData.txt to verify credentials
	file.open(filePath, ios::in);
	if (!file.is_open()) {
		gotoxy(55, 17);
		foreColor(4);
		cout << "Error: Unable to open loginData.txt file!";
		getch();
		return;
	}

	bool loginSuccess = false;

	// Reading Login Data
	while (getline(file, userName, '*')) {
		getline(file, Email, '*');
		getline(file, password, '\n');  // Reading password

		if (userName == searchName) {
			if (password == searchPass) {
				gotoxy(55, 18);
				foreColor(2);
				cout << "Account Login Successful...!";
				loginSuccess = true;
				getch();
				menu_admin();
				break;
			} else {
				gotoxy(55, 18);
				foreColor(4);
				cout << "Password is Incorrect...!";
				getch();
				loginSuccess = false;
				break;
			}
		}
	}

	// If login fails (user not found or password mismatch)
	if (!loginSuccess) {
		gotoxy(55, 21);
		foreColor(4);
		cout << "Login Failed. User not found!";
		gotoxy(55, 22);
		foreColor(4);
		cout << "===> Press any key to Exit <===";
		getch();
	}

	file.close();
}

void temp::forgot() {
	// Display Input Fields
	DrawRectangle(42, 9, 70, 1, 2);
	gotoxy(45, 10);
	foreColor(7);
	cout << "Enter Your User Name :: ";
	DrawRectangle(42, 12, 70, 1, 2);
	gotoxy(45, 13);
	foreColor(7);
	cout << "Enter Your Email Address :: ";

	// Input User Name with Validation
	while (true) {
		gotoxy(70, 10);
		foreColor(7);
		inputLetter(searchName);
		fflush(stdin);
		cin.clear();
		if (!searchName.empty()) {
			gotoxy(55, 18);cout << string(30, ' ');
			break;
		}
		
		gotoxy(55, 18);
		foreColor(4);
		cout << "User Name cannot be empty!  ";
		
	}

	// Input Email with Validation
	while (true) {
		gotoxy(75, 13);
		foreColor(7);
		getline(cin, searchEmail);
		fflush(stdin);
		cin.clear();
		if (!searchEmail.empty() && searchEmail.find('@') != string::npos && searchEmail.find('.') != string::npos) {
			gotoxy(55, 19);cout << string(50, ' ');
			break;
		}
		
		
		foreColor(4);
		gotoxy(55, 19);cout << "Invalid Email Address!        ";
		
	}

	// Check if User Exists
	bool accountFound = false;
	file.open(filePath, ios::in);
	if (!file.is_open()) {
		gotoxy(55, 20);
		foreColor(4);
		cout << "Error: Unable to open loginData.txt file! ";
		getch();
		return;
	}

	string existingUserName, existingEmail, existingPassword;
	while (getline(file, existingUserName, '*')) {
		getline(file, existingEmail, '*');
		getline(file, existingPassword, '\n');

		// Verify User Name and Email
		if (existingUserName == searchName && existingEmail == searchEmail) {
			accountFound = true;
			gotoxy(45, 21);
			foreColor(2);
			cout << "Account Found...!";
			DrawRectangle(42, 15, 70, 1, 2);
			gotoxy(45, 16);
			foreColor(7);
			cout << "Your Password :: " << existingPassword;
			break;
		}
	}
	file.close();

	// If no account is found, display an error message
	if (!accountFound) {
		gotoxy(45, 21);
		foreColor(4);
		cout << "User Name or Email not found!";
	}

	// Final exit prompt
	gotoxy(55, 22);
	foreColor(7);
	cout << "===> Press any key to Exit <===";
	getch();
}

void RegisterAdmin() {
	// Displaying the title at the top of the screen
	system("cls");
start:
	DrawRectangle(3, 1, 115, 1, 2);
	gotoxy(50, 2);
	foreColor(2);
	cout << "Employee Management";

	// Creating a big rectangle for the main area
	DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
	DrawRectangle(38, 5, 78, 18, 2);
	// Footer
	DrawRectangle(3, 26, 115, 1, 2);
	gotoxy(45, 27);
	foreColor(2);
	cout<<"Thank you for use our Application";
	// Left panel for welcome message
	DrawRectangle(5, 5, 30, 18, 131);
	gotoxy(10, 6);
	foreColor(7);
	cout << "Welcome to Employee";
	gotoxy(15, 7);
	foreColor(7);
	cout << "Management";
	DrawRectangle(16, 9, 8, 1, 7);
	gotoxy(18, 10);
	foreColor(2);
	cout << "Menu";
	char op;
	int x=1;
	do {
		gotoxy(10,12);
		foreColor(6);
		cout<<"[1] .Login";
		gotoxy(10,14);
		foreColor(6);
		cout<<"[2] .Sign-Up";
		gotoxy(10,16);
		foreColor(6);
		cout<<"[3] .Forgot Password";
		gotoxy(10,18);
		foreColor(6);
		cout<<"[4] .Exit";

		if(x==1) {
			gotoxy(10,12);
			foreColor(5);
			cout<<"[1] .Login";
		}
		if(x==2) {
			gotoxy(10,14);
			foreColor(5);
			cout<<"[2] .Sign-Up";
		}
		if(x==3) {
			gotoxy(10,16);
			foreColor(5);
			cout<<"[3] .Forgot Password";
		}
		if(x==4) {
			gotoxy(10,18);
			foreColor(5);
			cout<<"[4] .Exit";
		}
		op=getch();
		switch(op) {
			case 72: {
				x--;
				if(x<1) {
					x=5;
				}
				break;
			}
			case 80: {
				x++;
				if(x>5) {
					x=1;
				}
				break;
			}
		}

	} while(op!=13); //13 key Enter

	if(x==1) {
		system("cls");
		// Right panel for additional information or options
		//DrawRectangle(38, 5, 78, 18, 2);
		gotoxy(60,7);
		foreColor(5);
		cout<<"-------------Login\3-------------";
		// Displaying the title at the top of the screen
		DrawRectangle(3, 1, 115, 1, 2);
		gotoxy(50, 2);
		foreColor(2);
		cout << "Employee Management";

		// Creating a big rectangle for the main area
		DrawRectangle(3, 4, 115, 20, 2);
		// Right panel for additional information or options
		DrawRectangle(38, 5, 78, 18, 2);
		// Footer
		DrawRectangle(3, 26, 115, 1, 2);
		gotoxy(45, 27);
		foreColor(2);
		cout<<"Thank you for use our Application";
		// Left panel for welcome message
		DrawRectangle(5, 5, 30, 18, 131);
		gotoxy(10, 6);
		foreColor(7);
		cout << "Welcome to Employee";
		gotoxy(15, 7);
		foreColor(7);
		cout << "Management";
		DrawRectangle(12, 9, 16, 1, 7);
		gotoxy(14, 10);
		foreColor(2);
		cout << "Come join us!";
		gotoxy(6, 13);
		foreColor(7);
		cout<<"To get started, you'll need";
		gotoxy(6, 14);
		foreColor(7);
		cout<<"to create a user account.";
		gotoxy(6, 15);
		foreColor(7);
		cout<<"This will allow you to access,";
		gotoxy(6, 16);
		foreColor(7);
		cout<<"manage employee information";
		gotoxy(6, 17);
		foreColor(7);
		cout<<"streamline HR processes.";
		gotoxy(6, 18);
		foreColor(7);
		cout<<"If you don't have account'";
		gotoxy(6, 19);
		foreColor(7);
		cout<<"alrady!";
		gotoxy(6, 20);
		foreColor(7);
		cout<<"Go back and choose";
		gotoxy(15, 21);
		foreColor(4);
		cout<<"Sing-up!";
		//cin.ignore();
		objx.login();
		system("cls");
		goto start;
	}
	if(x==2) {
		system("cls");
		gotoxy(60,7);
		foreColor(5);
		cout<<"-------------Sign-Up\3-------------";
		DrawRectangle(3, 1, 115, 1, 2);
		gotoxy(50, 2);
		foreColor(2);
		cout << "Employee Management";

		// Creating a big rectangle for the main area
		DrawRectangle(3, 4, 115, 20, 2);
		// Right panel for additional information or options
		DrawRectangle(38, 5, 78, 18, 2);
		// Footer
		DrawRectangle(3, 26, 115, 1, 2);
		gotoxy(45, 27);
		foreColor(2);
		cout<<"Thank you for use our Application";
		// Left panel for welcome message
		DrawRectangle(5, 5, 30, 18, 131);
		gotoxy(10, 6);
		foreColor(7);
		cout << "Welcome to Employee";
		gotoxy(15, 7);
		foreColor(7);
		cout << "Management";
		DrawRectangle(12, 9, 16, 1, 7);
		gotoxy(14, 10);
		foreColor(2);
		cout << "Come join us!";
		gotoxy(6, 13);
		foreColor(7);
		cout<<"Signing up gives you";
		gotoxy(6, 14);
		foreColor(7);
		cout<<"personalized experiences,";
		gotoxy(6, 15);
		foreColor(7);
		cout<<"exclusive access, and";
		gotoxy(6, 16);
		foreColor(7);
		cout<<"efficient support. It";
		gotoxy(6, 17);
		foreColor(7);
		cout<<"also helps us improve the";
		gotoxy(6, 18);
		foreColor(7);
		cout<<"platform and communicate";
		gotoxy(6, 19);
		foreColor(7);
		cout<<"effectively.";
		gotoxy(6, 20);
		foreColor(7);
		cout<<"If you have account,";
		gotoxy(15, 21);
		foreColor(4);
		cout<<"Login!";
//		cin.ignore();
		objx.signUP();
		system("cls");
		goto start;
	}
	if(x==3) {
		system("cls");
		gotoxy(60,7);
		foreColor(5);
		cout<<"-------------Forgot Password\3-------------";
		DrawRectangle(3, 1, 115, 1, 2);
		gotoxy(50, 2);
		foreColor(2);
		cout << "Employee Management";

		// Creating a big rectangle for the main area
		DrawRectangle(3, 4, 115, 20, 2);
		// Right panel for additional information or options
		DrawRectangle(38, 5, 78, 18, 2);
		// Footer
		DrawRectangle(3, 26, 115, 1, 2);
		gotoxy(45, 27);
		foreColor(2);
		cout<<"Thank you for use our Application";
		// Left panel for welcome message
		DrawRectangle(5, 5, 30, 18, 131);
		gotoxy(10, 6);
		foreColor(7);
		cout << "Welcome to Employee";
		gotoxy(15, 7);
		foreColor(7);
		cout << "Management";
		DrawRectangle(12, 8, 16, 1, 7);
		gotoxy(14, 9);
		foreColor(2);
		cout << "Come join us!";
		gotoxy(6, 11);
		foreColor(7);
		cout<<"The provided code has ";
		gotoxy(6, 12);
		foreColor(7);
		cout<<"security vulnerabilities";
		gotoxy(6, 13);
		foreColor(7);
		cout<<"as it stores passwords";
		gotoxy(6, 14);
		foreColor(7);
		cout<<"efficient support. It";
		gotoxy(6, 15);
		foreColor(7);
		cout<<"in plain text. Consider";
		gotoxy(6, 16);
		foreColor(7);
		cout<<"using password hashing for";
		gotoxy(6, 17);
		foreColor(7);
		cout<<"enhanced security. For";
		gotoxy(6, 18);
		foreColor(7);
		cout<<"password recovery, send a";
		gotoxy(6, 19);
		foreColor(7);
		cout<<"reset link to the user's ";
		gotoxy(6, 20);
		foreColor(7);
		cout<<"email address and guide them";
		gotoxy(6, 21);
		foreColor(7);
		cout<<"through a secure password ";
		gotoxy(6, 22);
		foreColor(7);
		cout<<"reset process.";
//		cin.ignore();
		objx.forgot();
		system("cls");
		goto start;
	}
	if(x==4) {
		system("cls");
		foreColor(2);
		cout<<R"(
                     ,---.           ,---.
                    / /"`.\.--"""--./,'"\ \
                    \ \    _       _    / /
                     `./  / __   __ \  \,'
                      /    /_O)_(_O\    \
                      |  .-'  ___  `-.  |
                   .--|       \_/       |--.
                 ,'    \   \   |   /   /    `.
                /       `.  `--^--'  ,'       \
             .-"""""-.    `--.___.--'     .-"""""-.
.-----------/         \------------------/         \--------------.
| .---------\         /----------------- \         /------------. |
| |          `-`--`--'                    `--'--'-'             | |	
| |                                                             | |
| |                     Exit Program\3                          | |
| |      _____ _                 _     __   __                  | |
| |     |_   _| |__   __ _ _ __ | | __ \ \ / /__  _   _         | |
| |       | | | '_ \ / _` | '_ \| |/ /  \ V / _ \| | | |        | |
| |       | | | | | | (_| | | | |   <    | | (_) | |_| |        | |
| |       |_| |_| |_|\__,_|_| |_|_|\_\   |_|\___/ \__,_|        | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |_____________________________________________________________| |
|_________________________________________________________________|
                   )__________|__|__________(
                  |            ||            |
                  |____________||____________|
                    ),-----.(      ),-----.(
                  ,'   ==.   \    /  .==    `.
                 /            )  (            \
                 `==========='    `==========='  hjw	
	
	
	)";
		exit(0);
	}
	if(x==5){
		
	}
	system("cls");
	goto start;
}
#endif