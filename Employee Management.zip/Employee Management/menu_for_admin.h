#ifndef _MEUNU_FOR_ADMIN_
#define _MEUNU_FOR_ADMIN_

#include <iostream>
#include <conio.h>
#include <iomanip>
#include <fstream>
#include "antHeaderInput.h"
#include "antHeaderPlusPlus.h"
#include <vector>
#include <algorithm> // For std::sort
#include <limits>    // For numeric_limits
using namespace std;
// Constants for salary calculation
const double BONUS_RATE = 0.1;  // 10% bonus
const double TAX_RATE_1 = 0.02; // 2% tax
const double TAX_RATE_2 = 0.05; // 5% tax
const double TAX_RATE_3 = 0.15; // 15% tax
const double TAX_RATE_4 = 0.20; // 20% tax

const double TAX_REDUCTION_PER_CHILD = 150000; // Reduction per child per month
const double TAX_REDUCTION_PER_SPOUSE = 150000; // Reduction per spouse per month

// Function to calculate tax based on salary
double calculateTax(double salary) {
    double tax = 0.0;

    if (salary <= 1500000) {
        tax = salary * TAX_RATE_1;
    }
    else if (salary <= 2000000) {
        tax = 1500000 * TAX_RATE_1 + (salary - 1500000) * TAX_RATE_2;
    }
    else if (salary <= 8500000) {
        tax = 1500000 * TAX_RATE_1 + 500000 * TAX_RATE_2 + (salary - 2000000) * TAX_RATE_3;
    }
    else if (salary <= 12500000) {
        tax = 1500000 * TAX_RATE_1 + 500000 * TAX_RATE_2 + 6500000 * TAX_RATE_3 + (salary - 8500000) * TAX_RATE_4;
    }
    else {
        tax = 1500000 * TAX_RATE_1 + 500000 * TAX_RATE_2 + 6500000 * TAX_RATE_3 + 4000000 * TAX_RATE_4 + (salary - 12500000) * TAX_RATE_4;
    }

    return tax;
}

// CivilServants Class
class CivilServants {
public:
    // Member variables
    string name, work, telephone, ageInput, basicsalaryInput, spouseInput, childrenInput;
    int id, age, spouse, children;
    double basicsalary, bonus, tax, lastSalary;
 // Default Constructor
    CivilServants() : id(0), age(0), spouse(0), children(0),
                      basicsalary(0), bonus(0), tax(0), lastSalary(0) {}

    // Parameterized Constructor
    CivilServants(int _id, const string& _name, const string& _work, int _age, int _spouse, int _children,
                  double _basicsalary, const string& _telephone)
        : id(_id), name(_name), work(_work), age(_age), spouse(_spouse), children(_children),
          basicsalary(_basicsalary), bonus(0), tax(0), lastSalary(0), telephone(_telephone) {}

    // Calculate the bonus, tax, and final salary
    void calculateSalary() {
        bonus = basicsalary * BONUS_RATE;      // Apply the BONUS_RATE constant
        tax = ::calculateTax(basicsalary);     // Use global function to calculate tax
        lastSalary = basicsalary + bonus - tax;  // Final salary after tax and bonus
    }
    // Function to validate phone number
bool isValidPhoneNumber(const string &telephone) {
    return telephone.size() >= 9 && all_of(telephone.begin(), telephone.end(), ::isdigit);
}

// Function to validate that input contains only letters (for Name and Work)
bool isValidNameOrWork(const string &input) {
    return all_of(input.begin(), input.end(), ::isalpha);
}

// Function to validate if input is a valid number
bool isValidNumber(const string &input) {
    return !input.empty() && all_of(input.begin(), input.end(), ::isdigit);
}

    
    // Input function
    void input(int ID) {
        system("cls");

        
	gotoxy(60,7);foreColor(5);cout<<"-------------Add CivilScrvants\3-------------";
		// Displaying the title at the top of the screen
		DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
	
	gotoxy(30, 28);
    foreColor(2);
    cout << "Message";
    
	// Right panel for additional information or options
    DrawRectangle(38, 5, 83, 18, 2);
    // Left panel for welcome message
    
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    gotoxy(6, 13);foreColor(7);cout<<"To get started, you'll need";
    gotoxy(6, 14);foreColor(7);cout<<"to create a user account.";
    gotoxy(6, 15);foreColor(7);cout<<"This will allow you to access,";
    gotoxy(6, 16);foreColor(7);cout<<"manage employee information";
    gotoxy(6, 17);foreColor(7);cout<<"streamline HR processes.";
    gotoxy(6, 18);foreColor(7);cout<<"If you don't have account'";
    gotoxy(6, 19);foreColor(7);cout<<"alrady!";
    gotoxy(6, 20);foreColor(7);cout<<"Go back and choose";
    gotoxy(15, 21);foreColor(4);cout<<"Sing-up!";
	
	//
	// Input for Name
    while (true) {
        gotoxy(40, 10);
        foreColor(7);
        cout << "Enter Your Name: ";
        getline(cin, name);

        // Clear error message
        gotoxy(40, 25);
        cout << string(60, ' ');

        if (!name.empty() && isValidNameOrWork(name)) {
            break;
        }

        // Show error and clear input
        gotoxy(50, 25);
        foreColor(4);
        cout << "Name must contain only letters and cannot be empty!";
        gotoxy(40, 10);
        cout << string(77, ' '); // Clear the input area
    }

    // Input for Work
    while (true) {
        gotoxy(40, 12);
        foreColor(7);
        cout << "Enter Work: ";
        getline(cin, work);

        // Clear error message
        gotoxy(40, 26);
        cout << string(60, ' ');

        if (!work.empty() && isValidNameOrWork(work)) {
            break;
        }

        // Show error and clear input
        gotoxy(50, 26);
        foreColor(4);
        cout << "Work must contain only letters and cannot be empty!";
        gotoxy(40, 12);
        cout << string(77, ' '); // Clear the input area
    }

    // Input for Age
    while (true) {
        gotoxy(40, 14);
        foreColor(7);
        cout << "Enter Age: ";
        getline(cin, ageInput);

        // Clear error message
        gotoxy(40, 27);
        cout << string(60, ' ');

        if (isValidNumber(ageInput)) {
            age = stoi(ageInput);
            if (age > 0) {
                break;
            }
        }

        // Show error and clear input
        gotoxy(50, 27);
        foreColor(4);
        cout << "Age must be a valid number greater than 0!";
        gotoxy(40, 14);
        cout << string(77, ' '); // Clear the input area
    }

    // Input for Telephone
    while (true) {
        gotoxy(40, 16);
        foreColor(7);
        cout << "Enter Telephone: ";
        getline(cin, telephone);

        // Clear error message
        gotoxy(40, 28);
        cout << string(60, ' ');

        if (isValidPhoneNumber(telephone)) {
            break;
        }

        // Show error and clear input
        gotoxy(50, 28);
        foreColor(4);
        cout << "Telephone must be numeric and at least 9 digits!";
        gotoxy(40, 16);
        cout << string(77, ' '); // Clear the input area
    }

    // Input for Basic Salary
    while (true) {
    // Prompt user for basic salary
    gotoxy(40, 18);
    foreColor(7);
    cout << "Enter Basic Salary (KHR): ";
    
    // Get user input
    string basicsalaryInput;
    getline(cin, basicsalaryInput);

    // Clear previous error message
    gotoxy(40, 29);
    cout << string(60, ' ');

    // Validate input
    if (isValidNumber(basicsalaryInput)) {
        try {
            basicsalary = stol(basicsalaryInput); // Use stol for larger range
            if (basicsalary > 0) {
                break; // Valid salary entered
            }
        } catch (const out_of_range&) {
            // Handle case where number exceeds range
            gotoxy(50, 29);
            foreColor(4);
            cout << "Salary is too large! Enter a valid number.";
        }
    } else {
        // Handle invalid input
        gotoxy(50, 29);
        foreColor(4);
        cout << "Salary must be a valid number greater than 0!";
    }

    // Clear the input area
    gotoxy(40, 18);
    cout << string(77, ' '); // Clear previous input
}


    // Input for Spouse Count
    while (true) {
        gotoxy(40, 20);
        foreColor(7);
        cout << "Enter Spouse count: ";
        getline(cin, spouseInput);

        // Clear error message
        gotoxy(70, 30);
        cout << string(60, ' ');

        if (isValidNumber(spouseInput)) {
            spouse = stoi(spouseInput);
            if (spouse >= 0) {
                break;
            }
        }

        // Show error and clear input
        gotoxy(50, 30);
        foreColor(4);
        cout << "Spouse count must be a valid number (cannot be negative)!";
        gotoxy(40, 20);
        cout << string(82, ' '); // Clear the input area
    }

    // Input for Children Count
    while (true) {
        gotoxy(40, 22);
        foreColor(7);
        cout << "Enter Children count: ";
        getline(cin, childrenInput);

        // Clear error message
        gotoxy(40, 31);
        cout << string(70, ' ');

        if (isValidNumber(childrenInput)) {
            children = stoi(childrenInput);
            if (children >= 0) {
                break;
            }
        }

        // Show error and clear input
        gotoxy(50, 31);
        foreColor(4);
        cout << "Children count must be a valid number (cannot be negative)!";
        gotoxy(40, 22);
        cout << string(82, ' '); // Clear the input area
    }

    // Final Message
    gotoxy(47, 28);
    foreColor(2);
    cout << "All inputs have been successfully recorded. Thank you!";
	//

        // Clear input buffer and calculate salary
        cin.ignore(); 
        calculateSalary();
    }

    // Output function
    void output(int line) {
    gotoxy(40,5);foreColor(5);cout<<"-------------View CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    gotoxy(8, 7); 
	foreColor(5); 
	cout << left 
     << setw(8)  << "ID"            // ID
     << setw(25) << "Full Name"      // Full Name
     << setw(15) << "Work"           // Work
     << setw(8)  << "Age"            // Age
     << setw(18) << "Telephone"      // Telephone
     << setw(18) << "Basic Salary"   // Basic Salary
     << setw(18) << "Last Salary";   // Last Salary

	gotoxy(8, 8); 
	foreColor(4); 
	cout << "..............................................................................................................";
	
	// Display data with Telephone, Basic Salary, and Last Salary
	gotoxy(8, 7 + line); 
	foreColor(7); 
	cout << left 
     << setw(8)  << id              // ID
     << setw(25) << name            // Full Name
     << setw(15) << work            // Work
     << setw(8)  << age             // Age
     << setw(18) << telephone       // Telephone
     << setw(18) << fixed << setprecision(2) << basicsalary  // Basic Salary (with decimal support)
     << setw(18) << fixed << setprecision(2) << lastSalary;  // Last Salary (with decimal support)


    }
};

// Global variables
fstream file;
CivilServants obj;
int n = 1;

// Define the Attendance struct
struct Attendance {
    int id;            // Employee ID
    char date[11];     // Date in YYYY-MM-DD format
    char checkIn[6];   // Check-in time in HH:MM format
    char checkOut[6];  // Check-out time in HH:MM format or "N/A"
};

// Function to write data to the file
void WriteCivilServants() {
    int StartID = 100;

    ifstream search("Civilfile.bin", ios::in | ios::binary);
    if (search.is_open()) {
        search.seekg(0, ios::end);
        if (search.tellg() > 0) {
            search.seekg(-static_cast<int>(sizeof(obj)), ios::end);
            search.read((char*)&obj, sizeof(obj));
            StartID = obj.id;
        }
        search.close();
    }

    ofstream outfile("Civilfile.bin", ios::out | ios::app | ios::binary);
    if (!outfile.is_open()) {
        cout << "Error opening file for writing!" << endl;
        return;
    }

    obj.id = StartID + 1;
    obj.input(obj.id);
    outfile.write((char*)&obj, sizeof(obj));
    outfile.close();

    cout << "Record added with ID: " << obj.id << endl;
}
void ReadCivilServants() {
    int n = 3;  // Start displaying from line 5 (or any line suitable for your layout)

    // Open the file in binary read mode
    file.open("Civilfile.bin", ios::in | ios::binary);
    if (!file.is_open()) {
 cout << R"(
      444444444            000000000                 444444444  
      4::::::::4          00:::::::::00              4::::::::4  
     4:::::::::4        00:::::::::::::00           4:::::::::4  
    4::::44::::4       0:::::::000:::::::0         4::::44::::4  
   4::::4 4::::4       0::::::0   0::::::0        4::::4 4::::4  
  4::::4  4::::4       0:::::0     0:::::0       4::::4  4::::4  
 4::::4   4::::4       0:::::0     0:::::0      4::::4   4::::4  
4::::444444::::444     0:::::0 000 0:::::0     4::::444444::::444
4::::::::::::::::4     0:::::0 000 0:::::0     4::::::::::::::::4
4444444444:::::444     0:::::0     0:::::0     4444444444:::::444
          4::::4       0:::::0     0:::::0               4::::4  
          4::::4       0::::::0   0::::::0               4::::4  
          4::::4       0:::::::000:::::::0               4::::4  
        44::::::44      00:::::::::::::00              44::::::44
        4::::::::4        00:::::::::00                4::::::::4
        4444444444          000000000                  4444444444
    )";
        gotoxy(43, 33);  // Error message location (adjust if needed)
        foreColor(4);    // Color for error message
        cout << "File not found!";
        getch();
        return;  // Exit if file cannot be opened
    }

    // Clear previous content or messages from the display
    gotoxy(55, 24); foreColor(0); cout << "                                    ";

    // Read each record from the file and display it
    while (file.read((char*)&obj, sizeof(obj))) {
        obj.output(n);  // Output the current civil servant's details at the correct line
        n += 2;  // Adjust the row increment (set the correct number based on output format)
        
    }
    // If no records were read
    if (file.eof()) {
        gotoxy(44, 34); foreColor(2);
        cout << "End of records. No more data to display.";
        getch();
    }

    // Close the file after reading all records
    file.close();

}
void SearchCivilServants() {
    system("cls");
    gotoxy(60, 7); foreColor(5); cout << "-------------Search CivilServants-------------";
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
    DrawRectangle(3, 4, 120, 20, 2);
    DrawRectangle(38, 5, 83, 18, 2);
    DrawRectangle(3, 26, 120, 1, 2);
    gotoxy(50, 27); foreColor(2); cout << "Thank you for using our Application";
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    int SearchID;
    gotoxy(55, 9);
    foreColor(2);
    cout << "Enter Search ID of Civil Servants: ";
    SearchID = inputNumber();
	system("cls");
    file.open("Civilfile.bin", ios::in | ios::binary);
    if (!file.is_open()) {
        cout << R"(
      444444444            000000000                 444444444  
      4::::::::4          00:::::::::00              4::::::::4  
     4:::::::::4        00:::::::::::::00           4:::::::::4  
    4::::44::::4       0:::::::000:::::::0         4::::44::::4  
   4::::4 4::::4       0::::::0   0::::::0        4::::4 4::::4  
  4::::4  4::::4       0:::::0     0:::::0       4::::4  4::::4  
 4::::4   4::::4       0:::::0     0:::::0      4::::4   4::::4  
4::::444444::::444     0:::::0 000 0:::::0     4::::444444::::444
4::::::::::::::::4     0:::::0 000 0:::::0     4::::::::::::::::4
4444444444:::::444     0:::::0     0:::::0     4444444444:::::444
          4::::4       0:::::0     0:::::0               4::::4  
          4::::4       0::::::0   0::::::0               4::::4  
          4::::4       0:::::::000:::::::0               4::::4  
        44::::::44      00:::::::::::::00              44::::::44
        4::::::::4        00:::::::::00                4::::::::4
        4444444444          000000000                  4444444444
    )";
        gotoxy(43, 33);  
        foreColor(4);    
        cout << "File not found!";
        getch();
        return;  
    }

    bool found = false;
    int n = 8;  
	
    
    while (file.read((char*)&obj, sizeof(obj))) {
        if (SearchID == obj.id) { 
            obj.output(n);  // Display the details of the found record
            found = true;
            break;  // Exit the loop once the record is found
        }
        n += 8;  // Move to the next block for display
    }
    gotoxy(55, 24);foreColor(4);cout<<"Click Enter!";
    
	getch();system("cls");
    file.close();  // Ensure the file is closed

    // Message if the ID is not found
    if (!found) {
    	cout << R"(
      444444444            000000000                 444444444  
      4::::::::4          00:::::::::00              4::::::::4  
     4:::::::::4        00:::::::::::::00           4:::::::::4  
    4::::44::::4       0:::::::000:::::::0         4::::44::::4  
   4::::4 4::::4       0::::::0   0::::::0        4::::4 4::::4  
  4::::4  4::::4       0:::::0     0:::::0       4::::4  4::::4  
 4::::4   4::::4       0:::::0     0:::::0      4::::4   4::::4  
4::::444444::::444     0:::::0 000 0:::::0     4::::444444::::444
4::::::::::::::::4     0:::::0 000 0:::::0     4::::::::::::::::4
4444444444:::::444     0:::::0     0:::::0     4444444444:::::444
          4::::4       0:::::0     0:::::0               4::::4  
          4::::4       0::::::0   0::::::0               4::::4  
          4::::4       0:::::::000:::::::0               4::::4  
        44::::::44      00:::::::::::::00              44::::::44
        4::::::::4        00:::::::::00                4::::::::4
        4444444444          000000000                  4444444444
    )";
        gotoxy(55, 24);  // Clear any previous messages
        foreColor(4);
        cout << "Civil Servant with ID " << SearchID << " not found!";
        getch();
    }
}

void UpdateCivilServants() {
    system("cls");
	gotoxy(60,7);foreColor(5);cout<<"-------------Update CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";

    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 20, 2);
    // Right panel for additional information or options
    DrawRectangle(38, 5, 83, 18, 2);
    // Footer
    DrawRectangle(3, 26, 120, 1, 2);
    gotoxy(50, 27); foreColor(2); cout << "Thank you for using our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    int UpdateID;
    gotoxy(55, 9);
    foreColor(2);
    cout << "Enter Search ID of Civil Servants for Update: ";
    UpdateID = inputNumber();

    // Validate ID input
    if (UpdateID < 0) {
        gotoxy(75, 18);
        foreColor(4);
        cout << "Invalid ID! Please enter a positive number.";
        getch();
        return;
    }

    // Open file for both reading and writing in binary mode
    file.open("Civilfile.bin", ios::in | ios::out | ios::binary);
    if (!file.is_open()) {
        gotoxy(75, 18);
        foreColor(4);
        cout << "File not found or failed to open!";
        getch();
        return;
    }

    bool found = false;
    long recordPosition;  // Store the position of the record being updated

    while (file.read((char*)&obj, sizeof(obj))) {
        // If the civil servant with the specified ID is found
        if (UpdateID == obj.id) {
            found = true;

            gotoxy(55, 12);
            foreColor(2);
            cout << "Civil Servant found! Enter new details:";

            // Input new details, but keep the existing ID
            obj.input(UpdateID);

            // Store the current position of the record in the file
            recordPosition = file.tellg();  // Current read position after reading the record

            // Move the file pointer back to the position where the record needs to be updated
            file.seekp(recordPosition - static_cast<int>(sizeof(obj)), ios::beg);
            if (file.fail()) {
                gotoxy(55, 15);
                foreColor(4);
                cout << "Error setting file pointer for update!";
                getch();
                break;
            }

            // Write the updated record to the file
            file.write((char*)&obj, sizeof(obj));

            gotoxy(55, 26);
            foreColor(2);
            cout << "Update Successful!";
            getch();
            break;
        }
    }

    // If the record with the given ID was not found
    if (!found) {
    
        gotoxy(75, 18);
        foreColor(4);
        cout << "Civil Servant with ID " << UpdateID << " not found!";
        getch();
    }

    // Close the file after operations
    file.close();
}
void SortCivilServants() {
    system("cls");
    gotoxy(40,5);foreColor(5);cout<<"-------------Sort CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 83, 18, 2);
    // Footer
    DrawRectangle(3, 26, 120, 1, 2);
    gotoxy(50, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    // Left panel for welcome message
    vector<CivilServants> civilList; // Vector to store CivilServants data

    // Open the file and check if it's successful
    file.open("Civilfile.bin", ios::in | ios::binary);
    if (!file.is_open()) {
        gotoxy(55, 10);
        foreColor(4);
        cout << "No file found or failed to open!";
        getch();
        return;
    }

    // Load data from file into vector
    while (file.read((char*)&obj, sizeof(obj))) {
        civilList.push_back(obj);
    }
    file.close();

    // Check if vector is empty
    if (civilList.empty()) {
        gotoxy(55, 12);
        foreColor(4);
        cout << "No records to sort!";
        getch();
        return;
    }
	char op;
    int x = 1;  // Variable to track menu selection

    do {
        // Display menu options
        gotoxy(50, 10);
        foreColor(6);
        cout << "[1] .Sort by ID";
        gotoxy(50, 12);
        foreColor(6);
        cout << "[2] .Sort by Name";
        gotoxy(50, 14);
        foreColor(6);
        cout << "[3] .Sort by Basic Salary";
        gotoxy(50, 16);
        foreColor(6);
        cout << "[4] .Exit";

        // Highlight selected option
        if (x == 1) {
            gotoxy(50, 10);
            foreColor(5);
            cout << "[1] .Sort by ID";
        }
        if (x == 2) {
            gotoxy(50, 12);
            foreColor(5);
            cout << "[2] .Sort by Name";
        
		}
        if (x == 3) {
            gotoxy(50, 14);
            foreColor(5);
            cout << "[3] .Sort by Basic Salary";
        
        }
        if (x == 4) {
            gotoxy(50, 16);
            foreColor(5);
            cout << "[4] .Exit";
        }
        // Capture user input (arrow keys)
        op = getch();
        switch (op) {
            case 72: {  // Up arrow key
                x--;
                if (x < 1) {
                    x = 4;
                }
                break;  // Properly terminate the case
            }
            case 80: {  // Down arrow key
                x++;
                if (x > 4) {
                    x = 1;
                }
                break;  // Properly terminate the case
            }
        }
    } while (op != 13);  // Enter key to confirm selection

    // Show feedback based on the selected option
    if (x == 1) {
    	system("cls");
    	gotoxy(40,5);foreColor(5);cout<<"-------------View Sort by ID CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    	sort(civilList.begin(), civilList.end(), [](CivilServants a, CivilServants b) {
                return a.id < b.id;
            });
            
        
    }
    if (x == 2) {
    	system("cls");
    	gotoxy(40,5);foreColor(5);cout<<"-------------View Sort by Name CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
        sort(civilList.begin(), civilList.end(), [](CivilServants a, CivilServants b) {
                return a.name < b.name;
            });
            
    }
    if (x == 3) {
    	system("cls");
    	gotoxy(40,5);foreColor(5);cout<<"-------------View Sort by Basic Salary CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
        sort(civilList.begin(), civilList.end(), [](CivilServants a, CivilServants b) {
                return a.basicsalary < b.basicsalary;
            });
            
    }
    if (x == 4) {
    	system("cls");
    	gotoxy(40,5);foreColor(5);cout<<"-------------View CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
        gotoxy(55, 15);
            foreColor(4);
            cout << "Invalid choice!";
            return;
    }
    
    // Display sorted data
    system("cls");
    gotoxy(40,5);foreColor(5);cout<<"-------------View CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    gotoxy(12, 7);
    foreColor(5);
    cout << left << setw(10) << "ID" << setw(20) << "Full Name" << setw(15) << "Work" << setw(10) << "Age"
         << setw(20) << "Telephone" << setw(15) << "Basic Salary";
    gotoxy(10, 8);
    foreColor(4);
    cout << "................................................................................................................";

    int n = 1;
    for (CivilServants& obj : civilList) {
        gotoxy(12, 9 + n);
        foreColor(7);
        cout << left << setw(10) << obj.id << setw(20) << obj.name << setw(15) << obj.work
             << setw(10) << obj.age << setw(20) << obj.telephone << setw(15) << obj.basicsalary;
        n++;
    }

    gotoxy(45, 10 + n);
    foreColor(2);
    cout << "Sorting Complete. Press any key to return...";
    cin.ignore();
    cin.get();
}
void DeleteCivilServants() {
    system("cls");
    system("cls");
    gotoxy(40,5);foreColor(5);cout<<"-------------Delete CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 83, 18, 2);
    // Footer
    DrawRectangle(3, 26, 120, 1, 2);
    gotoxy(50, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    // Left panel for welcome message
    vector<CivilServants> civilList; // Vector to store CivilServants data

    ofstream backup;
    int Delete;
    bool recordDeleted = false;
    
    // Input Search ID
    gotoxy(55, 9);
    foreColor(2);
    cout << " Enter Search ID of Civil Servants for Delete: ";
    Delete = inputNumber();  // Input the ID to delete
    fflush(stdin);
    cin.clear();

    // Open Main File and Backup File
    file.open("Civilfile.bin", ios::in | ios::binary);
    backup.open("BackUpCivilfile.bin", ios::out | ios::binary);
    if (!file.is_open()) {  // Better check for file opening
        system("cls");
		cout << R"(
      444444444            000000000                 444444444  
      4::::::::4          00:::::::::00              4::::::::4  
     4:::::::::4        00:::::::::::::00           4:::::::::4  
    4::::44::::4       0:::::::000:::::::0         4::::44::::4  
   4::::4 4::::4       0::::::0   0::::::0        4::::4 4::::4  
  4::::4  4::::4       0:::::0     0:::::0       4::::4  4::::4  
 4::::4   4::::4       0:::::0     0:::::0      4::::4   4::::4  
4::::444444::::444     0:::::0 000 0:::::0     4::::444444::::444
4::::::::::::::::4     0:::::0 000 0:::::0     4::::::::::::::::4
4444444444:::::444     0:::::0     0:::::0     4444444444:::::444
          4::::4       0:::::0     0:::::0               4::::4  
          4::::4       0::::::0   0::::::0               4::::4  
          4::::4       0:::::::000:::::::0               4::::4  
        44::::::44      00:::::::::::::00              44::::::44
        4::::::::4        00:::::::::00                4::::::::4
        4444444444          000000000                  4444444444
    )";
        gotoxy(43, 33);  // Error message location (adjust if needed)
        foreColor(4);    // Color for error message
        cout << "File not found!";
        getch();
        return;
    }

    // Read and Copy Data to Backup File, except the Deleted Record
    while (file.read((char*)&obj, sizeof(obj))) {
        if (Delete == obj.id) {
            recordDeleted = true;  // Record Found for Deletion
            gotoxy(75, 20);
            foreColor(4);
            cout << "Record deleted successfully \3";
        } else {
            backup.write((char*)&obj, sizeof(obj));  // Copy other records to backup
        }
    }

    // Close Files
    backup.close();
    file.close();

    // Check if a record was deleted
    if (!recordDeleted) {
        gotoxy(75, 20);
        foreColor(4);
        cout << "Record not found with ID " << Delete << "!";
        getch();
    }

    // Delete Original File and Rename Backup File
    if (recordDeleted) {
        remove("Civilfile.bin");
        rename("BackUpCivilfile.bin", "Civilfile.bin");
    } else {
        remove("BackUpCivilfile.bin");  // Remove backup if no record is deleted
    }

    gotoxy(55, 22);
    foreColor(2);
    cout << "===> Press any key to Exit <===";
    getch();
}
void RecordAttendance() {
    system("cls");
    gotoxy(40, 5);
    foreColor(5);
    cout << "------------- Record Attendance for Employees -------------";
	DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 83, 18, 2);
    // Footer
    DrawRectangle(3, 26, 120, 1, 2);
    gotoxy(50, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    Attendance att;
    time_t t = time(0);
    struct tm* now = localtime(&t);
    string inputChoice;
    int searchID;

    // Get Employee ID
    gotoxy(40, 9);
    foreColor(2);
    cout << "Enter Employee ID for Attendance: ";
    searchID = inputNumber();

    // Open attendance file
    fstream attendanceFile("Attendance.bin", ios::in | ios::binary);
    if (!attendanceFile.is_open()) {
        // Create the file if it doesn't exist
        attendanceFile.open("Attendance.bin", ios::out | ios::binary);
        attendanceFile.close();
        attendanceFile.open("Attendance.bin", ios::in | ios::binary);
    }

    // Store current date
    strftime(att.date, sizeof(att.date), "%Y-%m-%d", now);

    // Get user input for check-in or check-out
    while (true) {
    gotoxy(40, 11);
    foreColor(2);
    cout << "Check-in or Check-out (in/out): ";
    cin >> inputChoice;

    // Clear any input error state
    cin.clear();  // Clear any error flags
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Ignore the rest of the input until a newline

    // Clear previous error message
    gotoxy(55, 16);
    cout << string(60, ' ');

    // Validate input
    if (inputChoice == "in" || inputChoice == "out") {
        break;
    }

    // Show error and clear input
    gotoxy(55, 16);
    foreColor(4);
    cout << "Invalid input! Please enter 'in' or 'out'.click enter";
    gotoxy(40, 11);  // Move to input position to clear the previous input
    cout << string(60, ' ');  // Clear the input area
    getch();  // Wait for the user to acknowledge the error
}

// Check-in logic
if (inputChoice == "in") {
    // Prepare attendance record for check-in
    att.id = searchID;
    strftime(att.checkIn, sizeof(att.checkIn), "%H:%M", now);
    strcpy(att.checkOut, "N/A"); // Initialize check-out as "N/A"

    // Append to the file
    attendanceFile.close();
    attendanceFile.open("Attendance.bin", ios::app | ios::binary);
    attendanceFile.write((char*)&att, sizeof(att));

    gotoxy(55, 14);
    foreColor(2);
    cout << "Check-in recorded for ID: " << searchID << " at " << att.checkIn;
} 
else if (inputChoice == "out") {
    Attendance tempAtt;
    bool found = false;

    // Open a temporary file
    fstream tempFile("TempAttendance.bin", ios::out | ios::binary);
    attendanceFile.seekg(0, ios::beg);

    // Process records to find a match
    while (attendanceFile.read((char*)&tempAtt, sizeof(tempAtt))) {
        if (tempAtt.id == searchID && strcmp(tempAtt.date, att.date) == 0 && strcmp(tempAtt.checkOut, "N/A") == 0) {
            found = true;
            strftime(tempAtt.checkOut, sizeof(tempAtt.checkOut), "%H:%M", now);

            gotoxy(55, 14);
            foreColor(2);
            cout << "Check-out recorded for ID: " << searchID << " at " << tempAtt.checkOut;
        }
        tempFile.write((char*)&tempAtt, sizeof(tempAtt));
    }

    attendanceFile.close();
    tempFile.close();

    if (!found) {
        gotoxy(55, 16);
        foreColor(4);
        cout << "No matching check-in record found for today.";
        getch();
        return;
    }
}


        // Replace original file with updated file
        remove("Attendance.bin");
        rename("TempAttendance.bin", "Attendance.bin");
    

    getch();
}

void DisplayAttendanceReport() {
	gotoxy(30,5);foreColor(5);cout<<"-------------DisplayAttendance Report CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    int SearchID;
    gotoxy(55, 9); 
    foreColor(2); 
    cout << "Enter Civil Servant ID to view attendance: ";
    SearchID = inputNumber();  // Input ID to search

    // Open the attendance file for reading
    fstream attendanceFile("Attendance.bin", ios::in | ios::binary);
    if (!attendanceFile.is_open()) {
        gotoxy(75, 18); 
        foreColor(4); 
        cout << "Error opening Attendance file!";
        return;
    }

    Attendance att;
    bool found = false;

    // Display headers for the report
    gotoxy(10, 11); 
    foreColor(2); 
    cout << left << setw(10) << "ID" << setw(12) << "Date" << setw(10) << "Check-In" << setw(10) << "Check-Out";
    gotoxy(10, 12); 
    cout << "--------------------------------------------";

    int row = 13;
    // Read the attendance records and display matching ones
    while (attendanceFile.read((char*)&att, sizeof(att))) {
        if (att.id == SearchID) {
            found = true;
            gotoxy(10, row++); 
            foreColor(7); 
            cout << left << setw(10) << att.id << setw(12) << att.date << setw(10) << att.checkIn << setw(10) << att.checkOut;
        }
    }

    // If no records are found
    if (!found) {
        gotoxy(55, 16); 
        foreColor(4); 
        cout << "No attendance records found for ID: " << SearchID;
    }

    attendanceFile.close();  // Close the attendance file
    system("cls");
}
void AttendanceSummaryReport() {
    system("cls");  // Clear the screen
	gotoxy(20,5);foreColor(5);cout<<"-------------Attendance Summary Report CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    // Display report header
//    gotoxy(10, 5); 
//    foreColor(2); 
//    cout << "Attendance Summary Report";
    gotoxy(10, 6); 
    cout << "------------------------------------------------------------";
    gotoxy(10, 7); 
    foreColor(5);
    cout << left << setw(10) << "ID" << setw(12) << "Date" 
         << setw(10) << "Check-In" << setw(10) << "Check-Out";
    gotoxy(10, 8); 
    cout << "------------------------------------------------------------";

    // Open the attendance file for reading
    fstream attendanceFile("Attendance.bin", ios::in | ios::binary);
    if (!attendanceFile.is_open()) {
        gotoxy(10, 10); 
        foreColor(4); 
        cout << "Error: Could not open Attendance file!";
        return;
    }

    Attendance att;
    int row = 9;
    
    // Read each attendance record and display it
    while (attendanceFile.read((char*)&att, sizeof(att))) {
        gotoxy(10, row++);
        foreColor(7);  // Set text color for records
        cout << left << setw(10) << att.id << setw(12) << att.date 
             << setw(10) << att.checkIn << setw(10) << att.checkOut;
    }

    // Close the file after reading
    attendanceFile.close();

    // Display end of report message
    gotoxy(10, row + 2); 
    foreColor(2); 
    cout << "==> End of Report <==";
    
    // Wait for user input before closing the report
    getch();
    system("cls");
}
void EmployeeSummaryReport() {
    system("cls");  // Clear the screen to display the report
	gotoxy(30,5);foreColor(5);cout<<"-------------Summary Report CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    // Display the report header
//    gotoxy(10, 5); 
//    foreColor(2); 
//    cout << "Employee Summary Report";
    gotoxy(10, 6); 
    cout << "----------------------------------------------------------------------------";
    gotoxy(10, 7); 
    foreColor(5);
    cout << left << setw(10) << "ID" << setw(20) << "Name" 
         << setw(15) << "Work" << setw(10) << "Age" << setw(15) << "Telephone";
    gotoxy(10, 8); 
    cout << "----------------------------------------------------------------------------";

    // Open the employee file for reading in binary mode
    file.open("Civilfile.bin", ios::in | ios::binary);
    if (!file.is_open()) {
        gotoxy(10, 10); 
        foreColor(4); 
        cout << "Error: Could not open file!";
        return;
    }

    int row = 9;
    while (file.read((char*)&obj, sizeof(obj))) {
        gotoxy(10, row++);
        foreColor(7);  // Set text color for employee records
        cout << left << setw(10) << obj.id << setw(20) << obj.name 
             << setw(15) << obj.work << setw(10) << obj.age 
             << setw(15) << obj.telephone;
    }

    file.close();  // Close the file after reading all records
    gotoxy(10, row + 2); 
    foreColor(2); 
    cout << "==> End of Report <==";  // Indicate end of the report
    getch();  // Wait for user input before closing the report
    system("cls");
}
void TaxDeductionReport() {
    system("cls");  // Clear the screen
	gotoxy(30,5);foreColor(5);cout<<"-------------Tex Dedument Report CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
//    gotoxy(10, 5); foreColor(2); 
//    cout << "Tax Deduction Report";
    gotoxy(10, 6); 
    cout << "--------------------------------------------------------------";
    gotoxy(10, 7); foreColor(5);
    cout << left << setw(10) << "ID" 
     << setw(20) << "Name" 
     << setw(15) << "Basic Salary" 
     << setw(10) << "Tax";
    gotoxy(10, 8); 
    cout << "--------------------------------------------------------------";

    file.open("Civilfile.bin", ios::in | ios::binary);
    if (!file.is_open()) {
        gotoxy(10, 10); foreColor(4); 
        cout << "Error: Could not open file!";
        return;
    }

    int row = 9;
    bool recordsFound = false;

    while (file.read((char*)&obj, sizeof(obj))) {
        // Ensure tax calculation is done and valid
        obj.calculateSalary();

        // Check if tax is calculated properly (could be extended based on your calculation logic)
        if (obj.tax >= 0) { 
            recordsFound = true;
            gotoxy(10, row++);
            foreColor(7);
            cout << left << setw(10) << obj.id
             << setw(20) << obj.name
             << setw(15) << fixed << setprecision(2) << obj.basicsalary
             << setw(10) << fixed << setprecision(2) << obj.tax;
        }
    }

    file.close();

    if (!recordsFound) {
        gotoxy(10, 10); foreColor(4); 
        cout << "No valid records found!";
    }

    gotoxy(10, row + 2); foreColor(2); 
    cout << "==> End of Report <==";
    getch();  // Wait for user input
    system("cls");
}

// Function to clear error message
void clearErrorMessage() {
    gotoxy(39, 25);
    foreColor(7);
    cout << "                                               ";
}

// Function to clear input line
void clearInputLine(int x, int y) {
    gotoxy(x, y);
    cout << "                                               ";
    gotoxy(x, y);
}

void CalculateSalaryForEmployee() {
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";

    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);
    foreColor(2);
    cout << "Thank you for using our Application";


    // Welcome message
    DrawRectangle(5, 5, 30, 28, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 10);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    gotoxy(7, 12);foreColor(6);cout<<"In this option you can ";
    gotoxy(7, 13);foreColor(7);cout<<"calculate the salary";
    gotoxy(7, 14);foreColor(7);cout<<"o verify. This calculation";
    gotoxy(7, 15);foreColor(7);cout<<"will not be stored in";
    gotoxy(7, 16);foreColor(7);cout<<"the program, it is just";
     gotoxy(7, 17);foreColor(7);cout<<"a simple calculation";

    double salary = 0.0;
    int numChildren = 0;
    char hasSpouseInput, spouseWorkingInput;
    bool hasSpouse = false, spouseWorking = false;

    // Input validation for salary
    while (true) {
        gotoxy(39, 6);
        foreColor(7);
        cout << "Enter monthly salary (in Riels): ";
        gotoxy(72, 6);
        foreColor(7);

        string salaryInput;
        getline(cin, salaryInput);

        try {
            salary = stod(salaryInput); // Convert string to double
            if (salary < 0) throw invalid_argument("Negative salary");
            break; // Exit loop if input is valid
        } catch (...) {
            clearErrorMessage();
            clearInputLine(72, 6);
            gotoxy(39, 25);
            foreColor(4);
            cout << "Invalid salary. Enter a valid positive number.";
            continue;
        }
    }
    clearErrorMessage();

    // Input validation for number of children
    while (true) {
        gotoxy(39, 8);
        foreColor(7);
        cout << "Enter number of children: ";
        gotoxy(65, 8);
        foreColor(7);

        string childrenInput;
        getline(cin, childrenInput);

        try {
            numChildren = stoi(childrenInput); // Convert string to integer
            if (numChildren < 0) throw invalid_argument("Negative number");
            break; // Exit loop if input is valid
        } catch (...) {
            clearErrorMessage();
            clearInputLine(65, 8);
            gotoxy(39, 25);
            foreColor(4);
            cout << "Invalid number of children. Enter a non-negative integer.";
            continue;
        }
    }
    clearErrorMessage();

    // Input validation for spouse status
    while (true) {
        gotoxy(39, 10);
        foreColor(7);
        cout << "Do you have a spouse? (y/n): ";
        gotoxy(70, 10);
        foreColor(7);

        string spouseInput;
        getline(cin, spouseInput);

        if (spouseInput == "y" || spouseInput == "Y") {
            hasSpouse = true;
            break;
        } else if (spouseInput == "n" || spouseInput == "N") {
            hasSpouse = false;
            break;
        } else {
            clearErrorMessage();
            clearInputLine(70, 10);
            gotoxy(39, 25);
            foreColor(4);
            cout << "Invalid spouse status. Enter 'y' or 'n'.";
        }
    }
    clearErrorMessage();

    // Input validation for spouse working status
    if (hasSpouse) {
        while (true) {
            gotoxy(39, 12);
            foreColor(7);
            cout << "Is your spouse working? (y/n): ";
            gotoxy(70, 12);
            foreColor(7);

            string workingInput;
            getline(cin, workingInput);

            if (workingInput == "y" || workingInput == "Y") {
                spouseWorking = true;
                break;
            } else if (workingInput == "n" || workingInput == "N") {
                spouseWorking = false;
                break;
            } else {
                clearErrorMessage();
                clearInputLine(70, 12);
                gotoxy(39, 25);
                foreColor(4);
                cout << "Invalid working status. Enter 'y' or 'n'.";
            }
        }
        clearErrorMessage();
    }

    // Apply tax reduction for children and spouse
    double totalReduction = numChildren * TAX_REDUCTION_PER_CHILD;
    if (hasSpouse && !spouseWorking) {
        totalReduction += TAX_REDUCTION_PER_SPOUSE; // Only if spouse exists and is not working
    }

    // Calculate the taxable income after reductions
    double taxableSalary = salary - totalReduction;
    if (taxableSalary < 0) {
        taxableSalary = 0; // Prevent negative taxable income
    }

    // Calculate the tax
    double tax = calculateTax(taxableSalary);

    // Calculate the last salary after tax deduction
    double lastSalary = salary - tax;

    // Output the results with full salary values (no scientific notation)
    gotoxy(39, 13);
    foreColor(2);
    cout << "----------------------------------------------------------------------------------";
    gotoxy(39, 14);
    foreColor(7);
    cout << "Result: ";
    cout << fixed << setprecision(0); // Ensure the output is in fixed format with no decimal points

    gotoxy(39, 15);
    foreColor(7);
    cout << "Base Salary: " << salary << " Riels\n";
    gotoxy(39, 17);
    foreColor(7);
    cout << "Tax Reduction for Children: " << numChildren * TAX_REDUCTION_PER_CHILD << " Riels\n";
    if (hasSpouse) {
        gotoxy(39, 19);
        foreColor(7);
        cout << "Tax Reduction for Spouse: " << (spouseWorking ? 0 : TAX_REDUCTION_PER_SPOUSE) << " Riels\n";
    }
    gotoxy(39, 21);
    foreColor(7);
    cout << "Taxable Salary after Reductions: " << taxableSalary << " Riels\n";
    gotoxy(39, 23);
    foreColor(7);
    cout << "Tax: " << tax << " Riels\n";
    gotoxy(39, 25);
    foreColor(7);
    cout << "Final Salary after Tax: " << lastSalary << " Riels\n";
    getch();
}


void menu_admin(){
	system("cls");
	start:
    // Displaying the title at the top of the screen
    DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 25, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 23, 2);
    gotoxy(70, 6);foreColor(6);cout<<"common options include:";
    gotoxy(40, 7);foreColor(7);cout<<"1. Add Employee: Input and save new employee details like ID,";
    gotoxy(40, 8);foreColor(7);cout<<"name, position, and department.";
    gotoxy(40, 9);foreColor(7);cout<<"2. View CivilServants: Display all civil servant records with their ";
    gotoxy(40, 10);foreColor(7);cout<<"detailed information.";
    gotoxy(40, 11);foreColor(7);cout<<"3. Sort CivilServants: Sort the list of civil servants based on criteria";
    gotoxy(40, 12);foreColor(7);cout<<"like name, ID, or department.";
    gotoxy(40, 13);foreColor(7);cout<<"4. Search CivilServants: Find specific civil servant details using ";
    gotoxy(40, 14);foreColor(7);cout<<"their ID or name.";
    gotoxy(40, 15);foreColor(7);cout<<"5. Update CivilServants: Edit information for an existing civil servant,";
    gotoxy(40, 16);foreColor(7);cout<<"such as their position or contact details.";
    gotoxy(40, 17);foreColor(7);cout<<"6. Delete CivilServant: Remove a civil servant's record from the system";
    gotoxy(40, 18);foreColor(7);cout<<"when they leave or retire.";
    gotoxy(40, 19);foreColor(7);cout<<"7. Attendance & Time Management: Track work hours, check-in/check-out";
    gotoxy(40, 20);foreColor(7);cout<<"times, and monitor attendance.";
    gotoxy(40, 21);foreColor(7);cout<<"8. Calculate Salary: Compute the monthly salary, including base pay,";
    gotoxy(40, 22);foreColor(7);cout<<"allowances, bonuses, and deductions.";
    gotoxy(40, 23);foreColor(7);cout<<"9. Reporting: Generate various reports on employee data, attendance,";
    gotoxy(40, 24);foreColor(7);cout<<"and salary details.";
    gotoxy(40, 25);foreColor(7);cout<<"10. Exit: Close the Employee Management System application.";
    // Footer
    DrawRectangle(3, 31, 115, 1, 2);
    gotoxy(45, 32);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 23, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    gotoxy(18, 8);
    foreColor(2);
    cout << "Menu";

    // Menu options
    char op;
    int x = 1;  // Variable to track menu selection

    do {
        // Display menu options
        gotoxy(5, 10);
        foreColor(6);
        cout << "[1] .Add CivilScrvants";
        gotoxy(5, 12);
        foreColor(6);
        cout << "[2] .View CivilScrvants";
        gotoxy(5, 14);
        foreColor(6);
        cout << "[3] .Sort CivilScrvants";
        gotoxy(5, 16);
        foreColor(6);
        cout << "[4] .Search CivilScrvants";
        gotoxy(5, 18);
        foreColor(6);
        cout << "[5] .Update CivilScrvants";
        gotoxy(5, 20);
        foreColor(6);
        cout << "[6] .Delete CivilScrvant";
        gotoxy(5, 22);
        foreColor(6);
        cout << "[7] .Attendance&Time Management";
        gotoxy(5, 24);
        foreColor(6);
        cout << "[8] .Calculate Salary";
        gotoxy(5, 26);
        foreColor(6);
        cout << "[9] .Reporting";
        gotoxy(5, 28);
        foreColor(6);
        cout << "[10] .Back to register";

        // Highlight selected option
        if (x == 1) {
            gotoxy(5, 10);
            foreColor(5);
            cout << "[1] .Add CivilScrvants";
        }
        if (x == 2) {
            gotoxy(5, 12);
            foreColor(5);
            cout << "[2] .View CivilScrvants";
        
		}
        if (x == 3) {
            gotoxy(5, 14);
            foreColor(5);
            cout << "[3] .Sort CivilScrvants";
        
        }
        if (x == 4) {
            gotoxy(5, 16);
            foreColor(5);
            cout << "[4] .Search CivilScrvants";
        
        }
        if (x == 5) {
            gotoxy(5, 18);
            foreColor(5);
            cout << "[5] .Update CivilScrvants";
        
        }
        if (x == 6) {
            gotoxy(5, 20);
            foreColor(5);
            cout << "[6] .Delete CivilScrvant";
        
        }
        if (x == 7) {
            gotoxy(5, 22);
            foreColor(5);
            cout << "[7] .Attendance&Time Management";
        
        }
        if (x == 8) {
            gotoxy(5, 24);
            foreColor(5);
            cout << "[8] .Calculate Salary";
        
        }
        if (x == 9) {
            gotoxy(5, 26);
            foreColor(5);
            cout << "[9] .Reporting";
        
        }
        if (x == 10) {
            gotoxy(5, 28);
            foreColor(5);
            cout << "[10] .Back to register";
        }
        // Capture user input (arrow keys)
        op = getch();
        switch (op) {
            case 72: {  // Up arrow key
                x--;
                if (x < 1) {
                    x = 10;
                }
                break;  // Properly terminate the case
            }
            case 80: {  // Down arrow key
                x++;
                if (x > 10) {
                    x = 1;
                }
                break;  // Properly terminate the case
            }
        }
    } while (op != 13);  // Enter key to confirm selection

    // Show feedback based on the selected option
    if (x == 1) {
    	system("cls");
    	WriteCivilServants();
    	system("cls");
        goto start;
    }
    if (x == 2) {
    	system("cls");
        ReadCivilServants();
        system("cls");
        goto start;
    }
    if (x == 3) {
    	system("cls");
        SortCivilServants();
        system("cls");
        goto start;
    }
    if (x == 4) {
    	system("cls");
        SearchCivilServants();
        
        system("cls");
        goto start;
    }
    if (x == 5) {
    	system("cls");
        UpdateCivilServants();
        system("cls");
        goto start;
    }
    if (x == 6) {
    	system("cls");
        DeleteCivilServants();
        system("cls");
        goto start;
    }
    if (x == 7) {
    	system("cls");
        RecordAttendance();
        system("cls");
        goto start;
    }
    if (x == 8) {
    	system("cls");
        CalculateSalaryForEmployee();
        system("cls");
        goto start;
    }
    if (x == 9) {
    system("cls");
    char reportOp;
    int reportChoice = 1;
    
    do {
    		gotoxy(40,5);foreColor(5);cout<<"-------------Reporting CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
        // Display the reporting options
        gotoxy(5, 10);
        foreColor(6);
        cout << "[1] .Attendance Summary Report";
        gotoxy(5, 12);
        foreColor(6);
        cout << "[2] .Employee Summary Report";
        gotoxy(5, 14);
        foreColor(6);
        cout << "[3] .Tax Deduction Report";
        gotoxy(5, 16);
        foreColor(6);
        cout << "[4] .Back to Main Menu";

        // Highlight the selected option
        if (reportChoice == 1) {
            gotoxy(5, 10);
            foreColor(5);
            cout << "[1] .Attendance Summary Report";
        }
        if (reportChoice == 2) {
            gotoxy(5, 12);
            foreColor(5);
            cout << "[2] .Employee Summary Report";
        }
        if (reportChoice == 3) {
            gotoxy(5, 14);
            foreColor(5);
            cout << "[3] .Tax Deduction Report";
        }
        if (reportChoice == 4) {
            gotoxy(5, 16);
            foreColor(5);
            cout << "[4] .Back to Main Menu";
        }

        // Capture user input for submenu
        reportOp = getch();
        switch (reportOp) {
            case 72: {  // Up arrow key
                reportChoice--;
                if (reportChoice < 1) {
                    reportChoice = 4;
                }
                break;
            }
            case 80: {  // Down arrow key
                reportChoice++;
                if (reportChoice > 4) {
                    reportChoice = 1;
                }
                break;
            }
        }
    } while (reportOp != 13);  // Enter key to confirm selection

    // Execute selected report function
    if (reportChoice == 1) {
        system("cls");
        AttendanceSummaryReport();
        goto start;
        system("cls");
    } 
    else if (reportChoice == 2) {
        system("cls");
        EmployeeSummaryReport();
        goto start;
        system("cls");
    } 
    else if (reportChoice == 3) {
        system("cls");
        TaxDeductionReport();
        goto start;
        system("cls");
    }
    else if (reportChoice == 4) {
        system("cls");
        goto start;
        system("cls");
    }
}

    if (x == 10) {
    	system("cls");
        
    }
    system("cls");
	
}
#endif