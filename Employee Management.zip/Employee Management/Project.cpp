#include <iostream>
#include <conio.h>
#include"home.h"
#include"register_for_admin.h"
#include"register_for_user.h"
#include"wellcom.h"
 using namespace std;
 
 int main(){
 	Welcome();
 	
 	
 	return 0;
 	getch();
 }