#ifndef _home_
#define _home_

#include <iostream>
#include <conio.h>  // Make sure to use a compiler that supports conio.h
#include "antHeaderPlusPlus.h" // Ensure this header file contains your required functions
#include"register_for_admin.h"
#include"register_for_user.h"
using namespace std;

void Home() {
	system("cls");
    // Displaying the title at the top of the screen
    DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 18, 2);
    gotoxy(70, 6);foreColor(6);cout<<"Introduction";
    gotoxy(40, 7);foreColor(7);cout<<"This Employee Management System, built in C++, enables efficient handling";
    gotoxy(40, 8);foreColor(7);cout<<"of employee records. Key features include adding,updating, searching,";
    gotoxy(40, 9);foreColor(7);cout<<"and deleting employee information, as well as saving data in external files";
    gotoxy(40, 10);foreColor(7);cout<<"for persistence. This project demonstrates C++ capabilities in data";
    gotoxy(40, 11);foreColor(7);cout<<"management, using core concepts like file handling and modular design";
    gotoxy(40, 12);foreColor(7);cout<<"to create a practical anduser-friendly solution.";
    gotoxy(40, 13);foreColor(4);cout<<"Before using the system, all users must first register an account.";
    gotoxy(40, 14);foreColor(7);cout<<"This ensures that only authorized personnel can access the system.";
    gotoxy(40, 15);foreColor(7);cout<<"There are two types of users:";
    gotoxy(40, 16);foreColor(4);cout<<"Admin: ";
    gotoxy(46, 16);foreColor(7);cout<<"Admin users have full access to all system functionalities, including";
    gotoxy(40, 17);foreColor(7);cout<<"adding, updating, searching, and deleting employee records.Admins can also";
    gotoxy(40, 18);foreColor(7);cout<<"also manage user accounts and configure system settings.";
    gotoxy(40, 19);foreColor(4);cout<<"Regular User: ";
    gotoxy(53, 19);foreColor(7);cout<<"Regular users have limited access, typically restricted to ";
    gotoxy(40, 20);foreColor(7);cout<<"viewing employee information or performing specific tasks as defined by ";
    gotoxy(40, 21);foreColor(7);cout<<"the admin. also manage user accounts and configure system settings.";
    // Footer
    DrawRectangle(3, 26, 115, 1, 2);
    gotoxy(45, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    gotoxy(18, 10);
    foreColor(2);
    cout << "Menu";

    // Menu options
    char op;
    int x = 1;  // Variable to track menu selection

    do {
        // Display menu options
        DrawRectangle(9, 12, 20, 1, 2);
        gotoxy(10, 13);
        foreColor(6);
        cout << "[1] .For Admin";
        DrawRectangle(9, 15, 20, 1, 2);
        gotoxy(10, 16);
        foreColor(6);
        cout << "[2] .For User";

        // Highlight selected option
        if (x == 1) {
            gotoxy(10, 13);
            foreColor(5);
            cout << "[1] .For Admin";
        }
        if (x == 2) {
            gotoxy(10, 16);
            foreColor(5);
            cout << "[2] .For User";
        }

        // Capture user input (arrow keys)
        op = getch();
        switch (op) {
            case 72: {  // Up arrow key
                x--;
                if (x < 1) {
                    x = 2;
                }
                break;  // Properly terminate the case
            }
            case 80: {  // Down arrow key
                x++;
                if (x > 2) {
                    x = 1;
                }
                break;  // Properly terminate the case
            }
        }
    } while (op != 13);  // Enter key to confirm selection

    // Show feedback based on the selected option
    if (x == 1) {
    	system("cls");
        RegisterAdmin();
    }
    if (x == 2) {
    	system("cls");
        RegisterUser();
    }
    system("cls");
}
#endif