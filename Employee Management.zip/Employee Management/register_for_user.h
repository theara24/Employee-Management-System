#ifndef _registerUser_
#define _registerUser_

#include <iostream>
#include <conio.h>
#include "antHeaderPlusPlus.h"
#include "antheaderInput.h"
#include <fstream>
#include "menu_for_user.h"

using namespace std;

class temps {
    string userNames, Emails, passwords;
    string searchNames, searchPasss, searchEmails;
    fstream file;
public:
    void logins();
    void signUPs();
    void forgots();
} objs;

void clearLine(int x, int y, int length) {
    gotoxy(x, y);
    for (int i = 0; i < length; i++) cout << " ";
    gotoxy(x, y);
}

void temps::signUPs() {
    // Display Input Fields
    DrawRectangle(42, 9, 70, 1, 2);
    gotoxy(45, 10); foreColor(7); cout << "Enter Your User Name :: ";
    DrawRectangle(42, 12, 70, 1, 2);
    gotoxy(45, 13); foreColor(7); cout << "Enter Your Emails Address :: ";
    DrawRectangle(42, 15, 70, 1, 2);
    gotoxy(45, 16); foreColor(7); cout << "Enter Your Passwords :: ";

    // Input User Name with Validation
    while (true) {
        clearLine(70, 10, 30);  // Clear the input area
        gotoxy(70, 10); foreColor(7); inputLetter(userNames); fflush(stdin); cin.clear();
        clearLine(55, 18, 40);  // Clear the error message
        if (!userNames.empty()) {
            break;
        }
        gotoxy(55, 18); foreColor(4); cout << "User Name cannot be empty!";
    }

    // Input Emails with Validation
    while (true) {
        clearLine(75, 13, 30);  // Clear the input area
        gotoxy(75, 13); foreColor(7); getline(cin, Emails); fflush(stdin); cin.clear();
        clearLine(55, 19, 40);  // Clear the error message
        if (!Emails.empty() && Emails.find('@') != string::npos && Emails.find('.') != string::npos) {
            break;
        }
        gotoxy(55, 19); foreColor(4); cout << "Invalid Emails Address!";
    }

    // Input Passwords with Hidden Characters
    while (true) {
        clearLine(70, 16, 30);  // Clear the input area
        gotoxy(70, 16); foreColor(7); hidePassword(passwords); fflush(stdin); cin.clear();
        clearLine(55, 20, 40);  // Clear the error message
        if (!passwords.empty()) {
            break;
        }
        gotoxy(55, 20); foreColor(4); cout << "Passwords cannot be empty!";
    }

    // Check for Duplicate UserNames or Emails
    bool isDuplicate = false;
    file.open("loginData.txt", ios::in|ios::out);
    if (!file.is_open()) {
        gotoxy(55, 21); foreColor(4); cout << "Error: Unable to open loginData.txt file!";
        getch();
        return;
    }

    string existingUserNames, existingEmails, existingPasswords;
    while (getline(file, existingUserNames, '*')) {
        getline(file, existingEmails, '*');
        getline(file, existingPasswords, '\n');

        if (existingUserNames == userNames || existingEmails == Emails) {
            isDuplicate = true;
            break;
        }
    }
    file.close();

    if (isDuplicate) {
        gotoxy(55, 22); foreColor(4); cout << "User Name or Emails already exists!";
        gotoxy(55, 23); foreColor(4); cout << "===> Press any key to Exit <===";
        getch();
        return;
    }

    // Save New User Data
    file.open("loginData.txt", ios::out | ios::app);
    if (!file.is_open()) {
        gotoxy(55, 21); foreColor(4); cout << "Error: Unable to open loginData.txt file for writing!";
        getch();
        return;
    }

    file << userNames << "*" << Emails << "*" << passwords << endl;
    file.close();

    gotoxy(55, 22); foreColor(2); cout << "Sign Up Successful!";
    getch();
    menu_user();
}

void temps::logins() {
    DrawRectangle(42, 9, 70, 1, 2);
    gotoxy(45, 10); foreColor(7); cout << "Enter Your User Name :: " << endl;
    DrawRectangle(42, 12, 70, 1, 2);
    gotoxy(45, 13); foreColor(7); cout << "Enter Your Passwords :: " << endl;

    // Input User Name
    while (true) {
        clearLine(70, 10, 30);  // Clear the input area
        gotoxy(70, 10); foreColor(7); inputLetter(searchNames); fflush(stdin); cin.clear();
        clearLine(55, 18, 40);  // Clear the error message
        if (!searchNames.empty()) {
            break;
        }
        gotoxy(55, 18); foreColor(4); cout << "User Name cannot be empty!";
    }

    // Input Passwords
    while (true) {
        clearLine(70, 13, 30);  // Clear the input area
        gotoxy(70, 13); foreColor(7); hidePassword(searchPasss); fflush(stdin); cin.clear();
        clearLine(55, 19, 40);  // Clear the error message
        if (!searchPasss.empty()) {
            break;
        }
        gotoxy(55, 19); foreColor(4); cout << "Passwords cannot be empty!";
    }

    // Open File
    file.open("loginData.txt", ios::in);
    if (!file.is_open()) {
        gotoxy(55, 17); foreColor(4); cout << "Error: Unable to open loginData.txt file!";
        getch();
        return;
    }

    bool loginSuccess = false;
    // Reading Login Data
    while (getline(file, userNames, '*')) {
        getline(file, Emails, '*');
        getline(file, passwords, '\n');

        if (userNames == searchNames) {
            if (passwords == searchPasss) {
                gotoxy(55, 18); foreColor(2); cout << "Account Login Successful...!";
                loginSuccess = true;
                getch();
                menu_user();
                break;
            } else {
                gotoxy(55, 18); foreColor(4); cout << "Passwords is Incorrect...!";
                getch();
                loginSuccess = false;
                break;
            }
        }
    }

    if (!loginSuccess) {
        gotoxy(55, 21); foreColor(4); cout << "Login Failed. User not found!";
        gotoxy(55, 22); foreColor(4); cout << "===> Press any key to Exit <===";
        getch();
    }

    file.close();
}

void temps::forgots() {
    // Display Input Fields
    DrawRectangle(42, 9, 70, 1, 2);
    gotoxy(45, 10); foreColor(7); cout << "Enter Your User Name :: ";
    DrawRectangle(42, 12, 70, 1, 2);
    gotoxy(45, 13); foreColor(7); cout << "Enter Your Emails Address :: ";

    // Input User Name with Validation
    while (true) {
        clearLine(70, 10, 30);  // Clear the input area
        gotoxy(70, 10); foreColor(7); inputLetter(searchNames); fflush(stdin); cin.clear();
        clearLine(55, 18, 40);  // Clear the error message
        if (!searchNames.empty()) {
            break;
        }
        gotoxy(55, 18); foreColor(4); cout << "User Name cannot be empty!";
    }

    // Input Emails with Validation
    while (true) {
        clearLine(75, 13, 30);  // Clear the input area
        gotoxy(75, 13); foreColor(7); getline(cin, searchEmails); fflush(stdin); cin.clear();
        clearLine(55, 19, 40);  // Clear the error message
        if (!searchEmails.empty() && searchEmails.find('@') != string::npos && searchEmails.find('.') != string::npos) {
            break;
        }
        gotoxy(55, 19); foreColor(4); cout << "Invalid Emails Address!";
    }

    // Check if User Exists
    bool accountFound = false;
    file.open("loginData.txt", ios::in);
    if (!file.is_open()) {
        gotoxy(55, 20); foreColor(4); cout << "Error: Unable to open loginData.txt file!";
        getch();
        return;
    }

    string existingUserNames, existingEmails, existingPasswords;
    while (getline(file, existingUserNames, '*')) {
        getline(file, existingEmails, '*');
        getline(file, existingPasswords, '\n');

        // Verify User Name and Emails
        if (existingUserNames == searchNames && existingEmails == searchEmails) {
            gotoxy(55, 21); foreColor(2); cout << "Your Password is: " << existingPasswords;
            accountFound = true;
            break;
        }
    }
    file.close();

    if (!accountFound) {
        gotoxy(55, 21); foreColor(4); cout << "Account not found!";
    }

    gotoxy(55, 23); foreColor(4); cout << "===> Press any key to Exit <===";
    getch();
}
void RegisterUser(){
	// Displaying the title at the top of the screen
	system("cls");
	start:
    DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 18, 2);
    // Footer
    DrawRectangle(3, 26, 115, 1, 2);
    gotoxy(45, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(16, 9, 8, 1, 7);
    gotoxy(18, 10);
    foreColor(2);
    cout << "Menu";
    char op;
	int x=1;
	do{
		gotoxy(10,12);foreColor(6);cout<<"[1] .Login";
		gotoxy(10,14);foreColor(6);cout<<"[2] .Sign-Up";
		gotoxy(10,16);foreColor(6);cout<<"[3] .Forgot Password";
		gotoxy(10,18);foreColor(6);cout<<"[4] .Exit";
		
		if(x==1){
			gotoxy(10,12);foreColor(5);cout<<"[1] .Login";
		}
		if(x==2){
			gotoxy(10,14);foreColor(5);cout<<"[2] .Sign-Up";
		}
		if(x==3){
			gotoxy(10,16);foreColor(5);cout<<"[3] .Forgot Password";
		}
		if(x==4){
			gotoxy(10,18);foreColor(5);cout<<"[4] .Exit";
		}
		op=getch();
		switch(op){
			case 72:{
				x--;  
				if(x<1){
					x=4;
				}
				break;
			}
			case 80:{  
				x++;  
				if(x>4){
					x=1;
				}
				break;
			}
		}
	
	}while(op!=13); //13 key Enter
	
	if(x==1){
	system("cls");
	// Right panel for additional information or options
    //DrawRectangle(38, 5, 78, 18, 2);
		gotoxy(60,7);foreColor(5);cout<<"-------------Login\3-------------";
		// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 18, 2);
    // Footer
    DrawRectangle(3, 26, 115, 1, 2);
    gotoxy(45, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    gotoxy(6, 13);foreColor(7);cout<<"To get started, you'll need";
    gotoxy(6, 14);foreColor(7);cout<<"to create a user account.";
    gotoxy(6, 15);foreColor(7);cout<<"This will allow you to access,";
    gotoxy(6, 16);foreColor(7);cout<<"manage employee information";
    gotoxy(6, 17);foreColor(7);cout<<"streamline HR processes.";
    gotoxy(6, 18);foreColor(7);cout<<"If you don't have account'";
    gotoxy(6, 19);foreColor(7);cout<<"alrady!";
    gotoxy(6, 20);foreColor(7);cout<<"Go back and choose";
    gotoxy(15, 21);foreColor(4);cout<<"Sing-up!";
		//cin.ignore();
        objs.logins();
        system("cls");
        goto start;
	}
	if(x==2){
		system("cls");
		gotoxy(60,7);foreColor(5);cout<<"-------------Sign-Up\3-------------";
		DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 18, 2);
    // Footer
    DrawRectangle(3, 26, 115, 1, 2);
    gotoxy(45, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 9, 16, 1, 7);
    gotoxy(14, 10);
    foreColor(2);
    cout << "Come join us!";
    gotoxy(6, 13);foreColor(7);cout<<"Signing up gives you";
    gotoxy(6, 14);foreColor(7);cout<<"personalized experiences,";
    gotoxy(6, 15);foreColor(7);cout<<"exclusive access, and";
    gotoxy(6, 16);foreColor(7);cout<<"efficient support. It";
    gotoxy(6, 17);foreColor(7);cout<<"also helps us improve the";
    gotoxy(6, 18);foreColor(7);cout<<"platform and communicate";
    gotoxy(6, 19);foreColor(7);cout<<"effectively.";
    gotoxy(6, 20);foreColor(7);cout<<"If you have account,";
    gotoxy(15, 21);foreColor(4);cout<<"Login!";
//		cin.ignore();
        objs.signUPs();
        system("cls");
        goto start;
	}
	if(x==3){
		system("cls");
		gotoxy(60,7);foreColor(5);cout<<"-------------Forgot Password\3-------------";
		DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 20, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 18, 2);
    // Footer
    DrawRectangle(3, 26, 115, 1, 2);
    gotoxy(45, 27);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 18, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    DrawRectangle(12, 8, 16, 1, 7);
    gotoxy(14, 9);
    foreColor(2);
    cout << "Come join us!";
    gotoxy(6, 11);foreColor(7);cout<<"The provided code has ";
    gotoxy(6, 12);foreColor(7);cout<<"security vulnerabilities";
    gotoxy(6, 13);foreColor(7);cout<<"as it stores passwords";
    gotoxy(6, 14);foreColor(7);cout<<"efficient support. It";
    gotoxy(6, 15);foreColor(7);cout<<"in plain text. Consider";
    gotoxy(6, 16);foreColor(7);cout<<"using password hashing for";
    gotoxy(6, 17);foreColor(7);cout<<"enhanced security. For";
    gotoxy(6, 18);foreColor(7);cout<<"password recovery, send a";
    gotoxy(6, 19);foreColor(7);cout<<"reset link to the user's ";
    gotoxy(6, 20);foreColor(7);cout<<"email address and guide them";
    gotoxy(6, 21);foreColor(7);cout<<"through a secure password ";
    gotoxy(6, 22);foreColor(7);cout<<"reset process.";
//		cin.ignore();
        objs.forgots();
        system("cls");
        goto start;
	}
	if(x==4){
		system("cls");
		foreColor(2);cout<<R"(
                     ,---.           ,---.
                    / /"`.\.--"""--./,'"\ \
                    \ \    _       _    / /
                     `./  / __   __ \  \,'
                      /    /_O)_(_O\    \
                      |  .-'  ___  `-.  |
                   .--|       \_/       |--.
                 ,'    \   \   |   /   /    `.
                /       `.  `--^--'  ,'       \
             .-"""""-.    `--.___.--'     .-"""""-.
.-----------/         \------------------/         \--------------.
| .---------\         /----------------- \         /------------. |
| |          `-`--`--'                    `--'--'-'             | |	
| |                                                             | |
| |                     Exit Program\3                          | |
| |      _____ _                 _     __   __                  | |
| |     |_   _| |__   __ _ _ __ | | __ \ \ / /__  _   _         | |
| |       | | | '_ \ / _` | '_ \| |/ /  \ V / _ \| | | |        | |
| |       | | | | | | (_| | | | |   <    | | (_) | |_| |        | |
| |       |_| |_| |_|\__,_|_| |_|_|\_\   |_|\___/ \__,_|        | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |                                                             | |
| |_____________________________________________________________| |
|_________________________________________________________________|
                   )__________|__|__________(
                  |            ||            |
                  |____________||____________|
                    ),-----.(      ),-----.(
                  ,'   ==.   \    /  .==    `.
                 /            )  (            \
                 `==========='    `==========='  hjw	
	
	
	)";
		exit(0);
	}
	system("cls");
	goto start;
}
#endif
