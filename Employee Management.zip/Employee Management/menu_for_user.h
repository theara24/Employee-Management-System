#ifndef _menuUser_
#define _menuUser_

#include <iostream>
#include <conio.h>
#include <iomanip>
#include <fstream>
#include "antHeaderInput.h"
#include "antHeaderPlusPlus.h"
#include "menu_for_admin.h"
#include <vector>
#include <algorithm> // For std::sort
#include <limits>    // For numeric_limits
using namespace std;

void menu_user(){
	system("cls");
	start:
    // Displaying the title at the top of the screen
    DrawRectangle(3, 1, 115, 1, 2);
    gotoxy(50, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 115, 25, 2);
	// Right panel for additional information or options
    DrawRectangle(38, 5, 78, 23, 2);
    gotoxy(70, 6);foreColor(6);cout<<"common options include:";
    gotoxy(40, 7);foreColor(7);cout<<"1. View CivilServants: Display all civil servant records with their ";
    gotoxy(40, 8);foreColor(7);cout<<"detailed information.";
    gotoxy(40, 9);foreColor(7);cout<<"2. Sort CivilServants: Sort the list of civil servants based on criteria";
    gotoxy(40, 10);foreColor(7);cout<<"like name, ID, or department.";
    gotoxy(40, 11);foreColor(7);cout<<"3. Search CivilServants: Find specific civil servant details using ";
    gotoxy(40, 12);foreColor(7);cout<<"their ID or name.";
    gotoxy(40, 13);foreColor(7);cout<<"4. Attendance & Time Management: Track work hours, check-in/check-out";
    gotoxy(40, 14);foreColor(7);cout<<"times, and monitor attendance.";
    gotoxy(40, 15);foreColor(7);cout<<"5. Calculate Salary: Compute the monthly salary, including base pay,";
    gotoxy(40, 16);foreColor(7);cout<<"allowances, bonuses, and deductions.";
    gotoxy(40, 17);foreColor(7);cout<<"6. Reporting: Generate various reports on employee data, attendance,";
    gotoxy(40, 18);foreColor(7);cout<<"and salary details.";
    gotoxy(40, 19);foreColor(7);cout<<"7. Exit: Close the Employee Management System application.";
    
    // Footer
    DrawRectangle(3, 31, 115, 1, 2);
    gotoxy(45, 32);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
    DrawRectangle(5, 5, 30, 23, 131);
    gotoxy(10, 6);
    foreColor(7);
    cout << "Welcome to Employee";
    gotoxy(15, 7);
    foreColor(7);
    cout << "Management";
    gotoxy(18, 8);
    foreColor(2);
    cout << "Menu";

    // Menu options
    char op;
    int x = 1;  // Variable to track menu selection

    do {
        // Display menu options
        gotoxy(5, 10);
        foreColor(6);
        cout << "[1] .View CivilScrvants";
        gotoxy(5, 12);
        foreColor(6);
        cout << "[2] .Sort CivilScrvants";
        gotoxy(5, 14);
        foreColor(6);
        cout << "[3] .Search CivilScrvants";
        gotoxy(5, 16);
        foreColor(6);
        cout << "[4] .Attendance&Time Management";
        gotoxy(5, 18);
        foreColor(6);
        cout << "[5] .Calculate Salary";
        gotoxy(5, 20);
        foreColor(6);
        cout << "[6] .Reporting";
        gotoxy(5, 22);
        foreColor(6);
        cout << "[7] .Back to register";
        

        // Highlight selected option
        if (x == 1) {
            gotoxy(5, 10);
            foreColor(5);
            cout << "[1] .View CivilScrvants";
        }
        if (x == 2) {
            gotoxy(5, 12);
            foreColor(5);
            cout << "[2] .Sort CivilScrvants";
        
		}
        if (x == 3) {
            gotoxy(5, 14);
            foreColor(5);
            cout << "[3] .Search CivilScrvants";
        
        }
        if (x == 4) {
            gotoxy(5, 16);
            foreColor(5);
            cout << "[4] .Attendance&Time Management";
        
        }
        if (x == 5) {
            gotoxy(5, 18);
            foreColor(5);
            cout << "[5] .Calculate Salary";
        
        }
        if (x == 6) {
            gotoxy(5, 20);
            foreColor(5);
            cout << "[6] .Reporting";
        
        }
        if (x == 7) {
            gotoxy(5, 22);
            foreColor(5);
            cout << "[7] .Back to register";
        
        }
        // Capture user input (arrow keys)
        op = getch();
        switch (op) {
            case 72: {  // Up arrow key
                x--;
                if (x < 1) {
                    x = 7;
                }
                break;  // Properly terminate the case
            }
            case 80: {  // Down arrow key
                x++;
                if (x > 7) {
                    x = 1;
                }
                break;  // Properly terminate the case
            }
        }
    } while (op != 13);  // Enter key to confirm selection

    // Show feedback based on the selected option
    if (x == 1) {
    	system("cls");
    	ReadCivilServants();
    	system("cls");
        goto start;
    }
    if (x == 2) {
    	system("cls");
        SortCivilServants();
        system("cls");
        goto start;
    }
    if (x == 3) {
    	system("cls");
        SearchCivilServants();
        system("cls");
        goto start;
    }
    if (x == 4) {
    	system("cls");
        RecordAttendance();
        system("cls");
        goto start;
    }
    if (x == 5) {
    	system("cls");
        CalculateSalaryForEmployee();
        system("cls");
        goto start;
    }
    if (x == 6) {
    	system("cls");
        char reportOp;
    int reportChoice = 1;
    
    do {
    		gotoxy(40,5);foreColor(5);cout<<"-------------Reporting CivilScrvants\3-------------";
	// Displaying the title at the top of the screen
    DrawRectangle(3, 1, 120, 1, 2);
    gotoxy(55, 2);
    foreColor(2);
    cout << "Employee Management";
	
    // Creating a big rectangle for the main area
    DrawRectangle(3, 4, 120, 30, 2);
    // Footer
    DrawRectangle(3, 36, 120, 1, 2);
    gotoxy(50, 37);foreColor(2);cout<<"Thank you for use our Application";
    // Left panel for welcome message
        // Display the reporting options
        gotoxy(5, 10);
        foreColor(6);
        cout << "[1] .Attendance Summary Report";
        gotoxy(5, 12);
        foreColor(6);
        cout << "[2] .Employee Summary Report";
        gotoxy(5, 14);
        foreColor(6);
        cout << "[3] .Tax Deduction Report";
        gotoxy(5, 16);
        foreColor(6);
        cout << "[4] .Back to Main Menu";

        // Highlight the selected option
        if (reportChoice == 1) {
            gotoxy(5, 10);
            foreColor(5);
            cout << "[1] .Attendance Summary Report";
        }
        if (reportChoice == 2) {
            gotoxy(5, 12);
            foreColor(5);
            cout << "[2] .Employee Summary Report";
        }
        if (reportChoice == 3) {
            gotoxy(5, 14);
            foreColor(5);
            cout << "[3] .Tax Deduction Report";
        }
        if (reportChoice == 4) {
            gotoxy(5, 16);
            foreColor(5);
            cout << "[4] .Back to Main Menu";
        }

        // Capture user input for submenu
        reportOp = getch();
        switch (reportOp) {
            case 72: {  // Up arrow key
                reportChoice--;
                if (reportChoice < 1) {
                    reportChoice = 6;
                }
                break;
            }
            case 80: {  // Down arrow key
                reportChoice++;
                if (reportChoice > 6) {
                    reportChoice = 1;
                }
                break;
            }
        }
    } while (reportOp != 13);  // Enter key to confirm selection

    // Execute selected report function
    if (reportChoice == 1) {
        system("cls");
        AttendanceSummaryReport();
        goto start;
        system("cls");
    } 
    else if (reportChoice == 2) {
        system("cls");
        EmployeeSummaryReport();
        goto start;
        system("cls");
    } 
    else if (reportChoice == 3) {
        system("cls");
        TaxDeductionReport();
        goto start;
        system("cls");
    }
    else if (reportChoice == 4) {
        system("cls");
        goto start;
        system("cls");
    }
    if (x == 7) {
    	system("cls");
        RecordAttendance();
        system("cls");
        goto start;
    
	}
}
    system("cls");
}
#endif